import React from 'react';
import './companyLeaderBoard.css';
import Header from '../../Components/Header/Header';
import {Footer} from '../../Components/Footer/Footer';
import Button from '../../Components/Shared/Button/Button';
import AppleIcon from '../../Assets/Images/Rectangle7.png';
import LeaderBoardItem from '../../Components/LeaderBoardItem/LeaderBoardItem';

const CompanyLeaderBoard = () => {
    return (
        <>
        <Header/>
        <div className="App">
        <div className="company-leaderboard">
            {/* Header */}
        <header className="header masthead">
            <div className="overlay"></div>
                <div className="container">
                <div className="row header-text">
                    <div className="col">
                    <p className="company-leaderboard-header-title">Supply Chain</p>
                    <span className="company-leaderboard-header-span">Company Leaderboard</span>
                    </div>
                </div>    
                </div>
            </header>  
            {/*Row one  */}
            <div className="row one"> 
            <div className="col-sm-12">
            <div className="one-text-box">
            <p className="one-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim  veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea  commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
            </div>
            </div>
            </div>  

        <div className="row four">
        <div className="col-sm-12">
        <div className="three-title-box">
        <p className="pagination">Showing 10 out of 1,500 companies</p>  
        </div>
        <div className="company_leaderboard_items">
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Samsung'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'} />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Samsung'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'}  />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Samsung'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'}  />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Samsung'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'}  />

        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Samsung'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'} />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Samsung'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'}  />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Samsung'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'}  />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Samsung'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'}  />
        
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Samsung'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'} />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Samsung'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'}  />
        <div className="btn-wrapper">
            <Button type="button" text="load more"/>
            </div>
        </div>
        </div>  
        </div> 
        </div>  
        <Footer/>  
        </div>    
        </>
    )
}

export default CompanyLeaderBoard;
