import React from 'react';
import './OurCause.css';
import Header from '../../Components/Header/Header';
import { Footer } from '../../Components/Footer/Footer';
import SDGImg from '../../Assets/Images/sdg-default 1.png';
import CoalitionImg from '../../Assets/Images/coalition 1.png'
import strategyImg from '../../Assets/Images/strategy 1.png';
import ForestImg from '../../Assets/Images/forest_SDGs-r4-12 1.png';
import AppleIcon from '../../Assets/Images/Rectangle7.png';
import LeaderBoardItem from '../../Components/LeaderBoardItem/LeaderBoardItem';
import Button from '../../Components/Shared/Button/Button';
import Data from '../../Assets/json/companies.json';
import * as Icons from '@fortawesome/free-brands-svg-icons';

const OurCause = () => {
    const list_company_leaderboard = () => {
        const filteredCompanies = Data.filter(({CompanyName}) =>  Icons[`fa${CompanyName}`] !== undefined);
        return filteredCompanies.map((company,index) => {
            const icon = Icons[`fa${company.CompanyName}`];
            return <LeaderBoardItem 
                        key={company.CompanyName}
                        itemIcon={icon}
                        itemName={company.CompanyName} 
                        Score={`LEAF Score: ${company.score || 'N/A'}`} 
                        num={index + 1} 
                        link={'View Profile'} />
        })
    }
    return (
        <>
        <Header/>
        <div className="App">
        <div className="our-cause">
        
        <header className="header masthead">
        <div className="overlay"></div>
            <div className="container">
            <div className="row header-text">
                <div className="col">
                <p className="our-cause-header-title">Our Cause</p>
                <span className="our-cause-header-span">Read more about LEAF and SDGs</span>
                </div>
            </div>    
            </div>
        </header>

        <div className="row one">
        <div className="col-sm-4">
        <div className='SDG-box'>
        <img src={CoalitionImg} alt="sustainable development goals"/>
        </div>
        
        </div>  
        <div className="col-sm-8">
            <div className="one-text-right-box">
            <p className="one-text-right">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim  veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea  commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
            </p>
            </div>
        
        </div>   
        </div>    
        <div className="row two">
        <div className="col-sm-7">
        <div className="two-text-left-box">
        <p className="two-text-left">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim  veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea  commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
        </div>
        </div>  
        <div className="col-sm-5">
        <div className="two-img-box">
            <img src={strategyImg} alt="strategy"/>
        </div>
        </div>   
        </div>  
        <div className="row three">
        <div className="col-sm-12">
        <div className="three-img-box">
            <img src={ForestImg} alt="forest"/>
        </div>
        </div>  
        </div>  
        {/* Row Four */}
        <div className="row four">
        <div className="col-sm-12">
        <p className="leaderboard">Company Leaderboard</p>
        <div className="company_leaderboard_items">
        {list_company_leaderboard()}
        {/* <LeaderBoardItem itemIcon={AppleIcon} itemName={'Apple'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'} />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Apple'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'}  />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Apple'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'}  />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Apple'} Score={'LEAF Score: 12.5'} num={'1'} link={'View Profile'}  /> */}
        <div className="btn-wrapper">
        <Button type="button" text="View All the Standings"/>
        </div>
        </div>
        </div>  
        </div>  
        {/* Row Five */}
        </div>
        <Footer/> 
        </div>
        </>
    )
}

export default OurCause;
