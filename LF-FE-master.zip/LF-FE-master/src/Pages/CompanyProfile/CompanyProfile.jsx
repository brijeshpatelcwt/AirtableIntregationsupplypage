import React, { useState, useEffect } from 'react';
import Header from '../../Components/Header/Header';
import GoalCard from '../../Components/GoalsCard/GoalsCard';
import GoalIcon1 from '../../Assets/Images/E_SDG-goals_icons-individual-rgb-01-copy 1.png';
import GoalIcon2 from '../../Assets/Images/TGG_Icon_Color_02 1.png';
import PostImage1 from '../../Assets/Images/Rectangle1.png';
import PostImage2 from '../../Assets/Images/Rectangle2.png'
import PostImage3 from '../../Assets/Images/Rectangle3.png'
import PostImage4 from '../../Assets/Images/Rectangle4.png'
import PostImage5 from '../../Assets/Images/Rectangle5.png'
import PostImage6 from '../../Assets/Images/Rectangle6.png'
import PostImage7 from '../../Assets/Images/Rectangle3.png'
import PostImage8 from '../../Assets/Images/Rectangle4.png'

import PostCard from './PostCard/PostCard';
import './CompanyProfile.css';

// Goals images
import Image1 from '../../Assets/Images/goals/E-WEB-Goal-1.png'

import AppleIcon from '../../Assets/Images/path188.png';
import { Footer } from '../../Components/Footer/Footer';
import AppleIcon1 from '../../Assets/Images/Rectangle7.png';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import * as Icons from '@fortawesome/free-brands-svg-icons';
import Loader from 'react-loader-spinner/index'
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css"

import CompanyList from '../../Assets/json/companies.json';
import SDGsList from '../../Assets/json/sdgs.json';
import {searchCompany, getCompanyGoal, getCompany} from '../../services/companies';
import NotFound404 from '../../Components/404/404';
import {getSdgs} from '../../services/sdgs';

const PostCardImages = { PostImage1, PostImage2, PostImage3, PostImage4, PostImage5, PostImage6, PostImage7, PostImage8}

const getMileStone = (com) => {
    console.log(com)
    return com.MilestonesAchieved?.split('>').filter(item => item.length > 20).map((item, key) =>
        <PostCard
        key={key}
        image={PostCardImages[`PostImage${(key+1) > 4 ? 5 : key+1}`]}
        title={item.split('').splice(0, 25).join('')}
        content={item}
        btn={null}
        />);
}

const getSDGs = (company) => {
    return company.SDGS?.map((sdg) => {
        if (Number(sdg.ID)) {
            return <img key={sdg.id} style={{margin:"5px 10px"}} src={require(`../../Assets/Images/goals/E-WEB-Goal-${sdg.ID}.png`)} alt={`SDG Goal No ${sdg.ID}`} />
        }
    })
}

const getSimilarCompany = (company, max=4) => {
  const similar = []
  console.log(company.similar)
  let index = 0;
  for(let val of company.similar) {
    if (index <= (max - 1)) {
      similar.push(val);
    }
    index++
  }
  return similar.map((comp, key) => <div key={key} className="company-item p-0">
  <img
    src={comp.Logo[0].thumbnails.large.url || AppleIcon1}
    alt={comp.Company + "'s logo"}
    className="p-0"
    style={{ minHeight: "30px", maxWidth: "100%"}}
    />
   <p className="name p-0 text-align-left">{comp.Company}<br/>
   <span className="score p-0 text-align-left">LEAF Score: &nbsp; &nbsp;<span style={{fontWeight:"bold"}}>{+(Math.round((comp.LeafScore) + "e+2")  + "e-2")}</span></span>
   </p>
  </div>)
}

const CompanyProfile = (props) => {
    const {location: { hash }} = props;
    const search = hash.replace(/%20/gi, ' ').replace('#', '');
    const [CompanyInfo, setCompanyInfo] = useState({})
console.log(CompanyInfo)
    useEffect(() => {
       window.scrollTo(0, 0)
    }, [])

    if(!CompanyInfo){
        return <NotFound404> <h3>Company profile does not exist.</h3></NotFound404>
    }

    !CompanyInfo.Company &&
        getCompany(search)
            .then(res => setCompanyInfo(res))
            .catch(err => {
                console.log(err)
                setCompanyInfo({ Company: ''})})


    const styles = { marginRight: "20px"}
    return !CompanyInfo.Company ?
      <NotFound404>
        <Loader
            type="Bars"
            color="#60a112"
            height={100}
            width={100}
            timeout={3000} //3 secs
        />
        </NotFound404> : (
        <>
        <Header/>
        <div className="App">
        <div className="company-profile">
        <header className="header masthead">
        {/* <div className="overlay"></div> */}
        <div className="container">
            <div className="header-box">
            <div className="row">
            <div className="col-sm-6" style={{borderRight:"0.5px solid #bdbdbd"}}>
            <div className="header-box-icon">
            <div className="company-logo" style={styles}>
        <img height="100" width="100" src={CompanyInfo.Logo[0].thumbnails.large.url || ''}/>
            </div>
{/* 
            <p className="name">{ CompanyInfo ? CompanyInfo.Company|| hash : "Apple inc."}<br/>
            <span className="year">Founded { CompanyInfo ? CompanyInfo.StartDate : "N/A"}</span>
            </p> */}
        </div>
            </div>
            <div className="col-sm-6">
            <div className="link_score-box">
            <p className="link"><i className="fas fa-link fa-2x"></i>
                { CompanyInfo.Source ? CompanyInfo.Source : "N/A"}
            </p>
            <p className="leaf_score"><i className="fas fa-cog fa-2x"></i>LEAF Score: { Math.round(CompanyInfo.LeafScore) } <span className="learn_more">(learn more)</span></p>
            </div>
            </div>
            </div>
            </div>
            </div>
        </header>
            { CompanyInfo && <>
            <div className="row one">
            <div className="col-sm-12">
            <div className="one-text-box">
            <p className="one-text">
            { CompanyInfo.Bio ? CompanyInfo.Bio : CompanyInfo.Targets }
            </p>
            </div>
            </div>
            </div>

            <div className="row two">
            <div className="col-sm-12">
                    <p className="row-titles">{ CompanyInfo ? CompanyInfo.Company: "Apple"}'s Global Goals { !CompanyInfo.SDGS && 'Not available at this time' }</p>
                </div>
                {/* <GoalCard color={'#E5233D'} icon={`../../Assets/Images/${SDGsList[0].Icon}`} name={SDGsList[0].Name} no={SDGsList[0].SDG_No}/>
                <GoalCard color={'#E5B735'} icon={`../../Assets/Images/${SDGsList[1].Icon}`} name={SDGsList[1].Name} no={SDGsList[1].SDG_No} /> */}

            <div style={{textAlign:"justify"}}>
                { CompanyInfo.SDGS.length!== 0?
                CompanyInfo.SDGS.map(item => {
                return <img style={{margin:"10px"}} height="100" width="100" src={item['Logo/Icon'][0].thumbnails.large.url}/>
                })
                :null }
            </div>
            </div>

            <div className="row three">
                <div className="col-sm-12" style={{marginBottom:"50px"}}>
                    <p className="row-titles" >{ CompanyInfo ? CompanyInfo.Company: "Apple"}’s Social Responsibility {!CompanyInfo.MilestonesAchieved && 'Not available at this time'}</p>
                </div>
                { getMileStone(CompanyInfo) }
            </div>
            </>}
        <div className="row four">
        <div className="col-sm-12">
        <p className="row-titles">Similar Companies</p>
        </div>

        <div className="col-sm-12 similar-companies">

        { getSimilarCompany(CompanyInfo) }


        </div>


        </div>
        </div>
        <Footer/>
        </div>
        </>
    )
}

export default CompanyProfile;
