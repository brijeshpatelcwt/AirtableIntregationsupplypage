import React from 'react';
import './PostCard.css';
import Button from '../../../Components/Shared/Button/Button';
import { Card } from 'react-bootstrap';
import Octicon from '@primer/octicons-react';


const PostCard =({image,icon,title,content,btn,className,buttonText,buttonClass,...otherProps}) => {
    let style;
    console.log(image)
    if(image !== undefined){
        style = {
            background: "url(" + image + ")", 
            height:"323px", 
            width: "626px"
        }
    }
    return (
        <div className="col-md-6">
        <div className={className}>
        <Card>
    <Card.Img variant="top" src={image} />
    <Card.Body>
      <Card.Text>
          <h3 className="text-dark">{title}{icon?<Octicon className="edit_icon" icon={icon}/>:null}</h3>
          {otherProps.goalsPicture?
        <div style={{display:"flex"}}>
        <img style={{marginRight:"2px",marginBottom:"2px"}} alt="image1" src={otherProps.goalsPicture.img1}/>  
        <img style={{marginRight:"2px",marginBottom:"2px"}} alt="image2" src={otherProps.goalsPicture.img2}/>    
        </div>
        :null}
          {content}
      </Card.Text>
    </Card.Body>
  </Card>
        {btn?
        <div className="post-card-transparent-btns-card">
        <button>SDG 1</button>
        <button>SDG 1</button>     
        </div>
        :null  
        }
        <div className="btn-wrapper">
        <Button classname={buttonClass || ''} text={buttonText || "Learn more"}/> 
        </div>
        </div>
        </div>    
       
    )
}

export default PostCard;
