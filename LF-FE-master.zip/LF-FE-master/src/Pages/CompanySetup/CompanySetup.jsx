import React  from 'react';
import { Auth } from 'aws-amplify';
import { useDispatch, useSelector } from 'react-redux';
import './CompanySetup.css';
import logo from '../../Assets/logo.png';
import {ReactComponent as PlaceholderIcon } from '../../Assets/Images/ant-design_picture-fill.svg';
import FormInput from '../../Components/InputBox/InputBox';
import Button from '../../Components/Shared/Button/Button';
import SDG from './SdgCards/SdgCards';
import Img1 from '../../Assets/Images/red.png';
import Img2 from '../../Assets/Images/yellow.png';
import Img3 from '../../Assets/Images/green.png';
import { logoutAccount } from '../../redux/reducer/generalReducer';

const CompanySetup = (props) => {
    const dispatch = useDispatch();
    const defaultState = useSelector(state => state.default.currentUser.payload)

    console.log(defaultState)
    const logOutUser = async () => {
        await Auth.signOut();
        await dispatch(logoutAccount())
        window.location.reload(false);
        props.history.push('/login')
    }

    if (!defaultState) {
      logOutUser()
    }
        return (
            <>
            <div className="company-header-setup">
            <img src={logo}
                height="30"
                className="d-inline-block align-top"
                alt="LEAF LOGO"
            />
            <p className="cursor-pointer" onClick={logOutUser}>Logout</p>
            </div>
            <div className="company-setup">

            <div className="company-setup-card">
            <p className="name">Hello, {defaultState.name}, </p>
            <p className="instruction">Please take some time to set up your company’s profile</p>
            <div className="logos-box">
            <div>
            <PlaceholderIcon className="logo"/>
            <p className="add-logo">Add Company Logo</p>
            </div>
            <div>
            <PlaceholderIcon className="logo"/>
            <p className="com-photos">Add More Company Photos</p>
            </div>
            </div>

            <form>
            <div className="row">
            {/* Row one */}
            <div className="col-sm-6"><FormInput className="setup-style" type="text" label="Company Name (In Full)" placeholder="Enter Company Name in full"/></div>
            <div className="col-sm-6"><FormInput className="setup-style" type="text" label="Date Founded" placeholder="Add year founded here"/></div>

            {/* Row two */}
            <div className="col-sm-6"><FormInput className="setup-style" type="text" label="Company Sector" placeholder="Select Company Sector"/></div>
            <div className="col-sm-6"><FormInput className="setup-style" type="text" label="Coalition Opt-in" placeholder="Yes"/></div>

            {/* Row three */}
            <div className="col-sm-12"><FormInput className="setup-style" textarea type="text" label="Company Bio" placeholder="Enter company bio here" rows="4"/></div>
            </div>
            <p className="sust-dev-title">Sustainable Development Goals (SDGs)</p>
            <div className="sust-dev-goals">
             <div style={{display:"flex",flexDirection:"row",justifyContent:"space-between"}}>
             <p className="select-sdgs">Select applicable SDGs </p>
            <div className="form-check">
            <label className="form-check-label" style={{marginRight:"25px"}}>
            Select all 17
            </label>
            <input className="form-check-input" type="radio" value="option1"/>
            </div>
            </div>
            <SDG image={Img1} text="Ensure healthy lives and promote well-being for all people" metric="SDG Metric - "/>
            <SDG image={Img2} text="Ensure healthy lives and promote well-being for all people" metric="SDG Metric - "/>
            <SDG image={Img3} text="Ensure healthy lives and promote well-being for all people" metric="SDG Metric - "/>
            </div>
            <div className="submit-btn-div">
            <Button text="submit"/>
            </div>
            </form>
            </div>

            </div>
            </>
        )
}

export default CompanySetup
