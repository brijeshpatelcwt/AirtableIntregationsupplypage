import React from 'react';
import './SdgCards.css';
const SdgCards = ({image,text,metric}) => {
    return (
        <div className="sdg-cards">
        <img  className="sdg-img" src={image} />    
        <p className="text">{text}<br/>
        <span className="metric">{metric}</span>
        </p>
        <input className="form-check-input" type="radio" value="option1"/>
        </div>
    )
}

export default SdgCards;
