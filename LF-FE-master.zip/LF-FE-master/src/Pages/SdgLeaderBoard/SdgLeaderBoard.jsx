import React from 'react';
import './SdgLeaderBoard.css';
import Header from '../../Components/Header/Header';
import {Footer} from '../../Components/Footer/Footer';
import Button from '../../Components/Shared/Button/Button';
import Menu from '../../Components/LeaderBoardItem/LeaderBoardItem';
import EndPoverty from '../../Assets/Images/goals/E-WEB-Goal-01 1.png';
import EndHunger from '../../Assets/Images/goals/E-WEB-Goal-2.png';
import GoodHealth from '../../Assets/Images/goals/E-WEB-Goal-03 1.png';
import QualityEducation from '../../Assets/Images/goals/E-WEB-Goal-4.png';

const SdgLeaderBoard = () => {
    return (
        <>
        <Header/>
        <div className="App">
        <div className="sdg-leaderboard">
            {/* Header */}
        <header className="header masthead">
            <div className="overlay"></div>
                <div className="container">
                <div className="row header-text">
                    <div className="col">
                    <p className="sdg-leaderboard-header-title">Supply Chain</p>
                    <span className="sdg-leaderboard-header-span">SDG Leaderboard</span>
                    </div>
                </div>    
                </div>
            </header>  
            {/*Row one  */}
            <div className="row one"> 
            <div className="col-sm-12">
            <div className="one-text-box">
            <p className="one-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim  veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea  commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
            </div>
            </div>
            </div>  

            <div className="row three">
    
            <div className="col-sm-12">
            <div className="three-title-box">
             <p className="top-sdgs">Showing 10 out of 17 SDGs</p>  
            </div>
            </div>
            <div className="col-sm-12">
            <Menu className="border-left-red" itemIcon={EndPoverty} itemName={'End Poverty'} Score={'70%'} num={'1'} link={'Learn More'} />
            <Menu className="border-left-yellow" itemIcon={EndHunger} itemName={'End Hunger'} Score={'60%'} num={'2'} link={'Learn More'}  />
            <Menu className="border-left-red" itemIcon={GoodHealth} itemName={'End Poverty'} Score={'70%'} num={'1'} link={'Learn More'}  />
            <Menu className="border-left-yellow" itemIcon={QualityEducation} itemName={'End Hunger'} Score={'60%'} num={'2'} link={'Learn More'}/>

            <Menu className="border-left-red" itemIcon={EndPoverty} itemName={'End Poverty'} Score={'70%'} num={'1'} link={'Learn More'} />
            <Menu className="border-left-yellow" itemIcon={EndHunger} itemName={'End Hunger'} Score={'60%'} num={'2'} link={'Learn More'}  />
            <Menu className="border-left-red" itemIcon={GoodHealth} itemName={'End Poverty'} Score={'70%'} num={'1'} link={'Learn More'}  />
            <Menu className="border-left-yellow" itemIcon={QualityEducation} itemName={'End Hunger'} Score={'60%'} num={'2'} link={'Learn More'}/>

            <Menu className="border-left-red" itemIcon={EndPoverty} itemName={'End Poverty'} Score={'70%'} num={'1'} link={'Learn More'} />
            <Menu className="border-left-yellow" itemIcon={EndHunger} itemName={'End Hunger'} Score={'60%'} num={'2'} link={'Learn More'}  />
            <div className="btn-wrapper">
            <Button type="button" text="load more"/>
            </div>
            </div> 
            </div>
        </div>  
        <Footer/>  
        </div>    
        </>
    )
}

export default SdgLeaderBoard;
