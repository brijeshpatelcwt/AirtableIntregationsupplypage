import React,{Component} from 'react';
import './SupplyChain.css';
import Header from '../../Components/Header/Header';
import {Footer} from '../../Components/Footer/Footer';
import Search from '../../Components/Search/Search';
import VectorIcon from '../../Assets/Images/Vector.png';
import SectorsCard from '../../Components/SectorsCard/SectorsCard';
import Menu from '../../Components/LeaderBoardItem/LeaderBoardItem';
import EndPoverty from '../../Assets/Images/goals/E-WEB-Goal-01 1.png';
import EndHunger from '../../Assets/Images/goals/E-WEB-Goal-2.png';
import GoodHealth from '../../Assets/Images/goals/E-WEB-Goal-03 1.png';
import QualityEducation from '../../Assets/Images/goals/E-WEB-Goal-4.png';
import AppleIcon from '../../Assets/Images/Rectangle7.png';
import LeaderBoardItem from '../../Components/LeaderBoardItem/LeaderBoardItem';
import Restaurant from '../../Assets/Images/restaurant 1.png'
import Button from '../../Components/Shared/Button/Button';
import { getAllCompanies, getSingleCompany } from '../../services/companies';
import { getAllSdgs} from '../../services/sdgs';
import TechnologyIcon from '../../Assets/Images/tech 1.png'

import { getAllUsers } from '../../services/userdata';
import { getAllSectors } from '../../services/sectordata';

class SupplyChain extends Component{
        constructor(props){
            super(props);
            this.state = {
                sectordata:[],
                sdgsdata:[],
            }
        }




    handleChange = (e) => {
        const { value } = e.target;
        this.setState({companies:value})
    }
    search = (e) => {
        e.preventDefault();
        const { companies } = this.state;
        console.log(companies)
       getSingleCompany(companies)
    }

    componentDidMount(){     
    console.log(getAllSdgs())

    fetch('https://api.airtable.com/v0/appHjax74n4pApmdG/Sectors?api_key=key64OdXrH1Y0aZo0')
    .then((resp) => resp.json())
    .then(data => {
      console.log(data);
      this.setState({ sectordata: data.records });
    }).catch(err => {
      // Error
    });

    fetch('https://api.airtable.com/v0/appHjax74n4pApmdG/SDGS?api_key=key64OdXrH1Y0aZo0')
    .then((resp) => resp.json())
    .then(data => {
      console.log(data);
      this.setState({ sdgsdata: data.records });
    }).catch(err => {
      // Error
    });
    
    }

    parseData (record) {
    return record.data;
    
  }
    render(){
    
        return (
              
            <>
            <Header/>
            
            <div className="App">
            <div className="supply-chain">
            <header className="header masthead">
            <div className="overlay"></div>
                <div className="container">
                <div className="row header-text">
                    <div className="col">
                    <p className="supply-chain-header-title">Supply Chain</p>
                    <span className="supply-chain-header-span">Find Companies. Read their goals. Track SDGs.</span>
                    <Search  history={this.props.history} placeholder="Find Companies, read their goals. Track thier SDG's"/>
                    </div>
                </div>    
                </div>
            </header>  
            <div className="container-fluid">
            <div className="row one"> 
            <div className="col-md-4">
            <div className="one-icon-box">
            <img src={VectorIcon} alt="icon"/>
            </div>
            </div>
            <div className="col-md-8">
            <div className="one-text-box">
            <p className="one-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim  veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea  commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
            </div>
            </div>
            </div>
            </div>  
            
            <div className="container-fluid">
            <div className="row two">
            <div className="col-md-12">
            <div className="two-title-box">
             <p className="top-sectors">Top Performing Sectors</p> 
             <a className="all-sectors" href="#">View All  Sectors></a>  
            </div>
            <div className="row">
            {this.state.sectordata.map(sector => <SectorsCard {...sector.fields} /> )}
           
            </div>
            </div>
            </div>
            </div>
             
             <div className="container-fluid">   
            <div className="row three">
    
            <div className="col-md-12">
            <div className="three-title-box">
             <p className="top-sdgs">Top Performing SDGs</p> 
             <a className="all-rankings" href="#">View Full Rankings></a>  
            </div>
            </div>
            <div className="col-md-12">

            {this.state.sdgsdata.map(sdgsd => <Menu {...sdgsd.fields} /> )}
            
            </div> 
            </div>  
            </div>
            <div className="container-fluid">
        <div className="row four">
        <div className="col-md-12">
        <div className="three-title-box">
        <p className="top-sdgs">Company Leaderboard</p>  
        </div>
        <div className="company_leaderboard_items">


  
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Apple'} Score={'LEAF Score: 14.5'} num={'1'} link={'View Profile'} />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Apple'} Score={'LEAF Score: 14.5'} num={'1'} link={'View Profile'}  />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Apple'} Score={'LEAF Score: 14.5'} num={'1'} link={'View Profile'}  />
        <LeaderBoardItem itemIcon={AppleIcon} itemName={'Apple'} Score={'LEAF Score: 14.5'} num={'1'} link={'View Profile'}  />
        <div className="btn-wrapper">
        <Button type="button" text="View All the Standings"/>
        </div>
        </div>
        </div>  
        </div> 
        </div>

            </div>
            <Footer/>
            </div>
            </>
        )
    }

}

export default SupplyChain;
