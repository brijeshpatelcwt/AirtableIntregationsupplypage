import React from 'react';
import NavBar from '../../Components/Shared/NavBar';
import './Landing.css';
import Button from '../../Components/Shared/Button/Button';
import CompanyListItem from '../../Components/CompanyListItem/CompanyListItem';
import buildingImg from '../../Assets/Images/modern-building.svg';
import sdgLogoLarge from '../../Assets/Images/sdg-logo-lg.png';
import sdgLogoSmall from '../../Assets/Images/sdg-logo-sm.png';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import * as Icons from '@fortawesome/free-brands-svg-icons';
import { useState } from 'react';
import { searchCompany } from '../../services/companies';
import Search from '../../Components/Search/Search';

import { getAllUsers } from '../../services/userdata'; 

const getCompanies = (companies) => {
 // console.log(companies)
  const filteredCompanies = companies.filter(({Company, Bio}) => (Icons[`fa${Company}`] || Bio));
  return filteredCompanies.map(item => {
    const subTitle = item.Bio.split("",100);
    const icon = item.Logo? item.Logo[0].thumbnails.large.url:null || Icons[`fa${item.Company}`] || Icons[`faEnvira`];

    return(
    <CompanyListItem
      key={item.Company}
      bgColor="#b3b3b3"
      icon={icon}
      url={item.id} 
      companyTitle={item.Name}
      companySubtitle={subTitle || 'N/A'}
    />)
  })
}


const Landing = ({props}) => {
  const [ companies, setCompanies ] = useState([])
  !companies.length &&
    searchCompany('', 8)
        .then(setCompanies)
        .then()
  return (
    <div className="wrapper">
      <section id="background">
        <div id="bg-overlay"></div>

        <div className="header-content">
          <div className="header-text">
            <h2 className="header-title">Let's Make the world a <br/> better place...</h2>
            <p className="header-subtitle">Leaf is a Funnel for Lead Generation and Trackling For the coalition,
            It is a network built to Equip The U.S To Accelerate and Achieve Rapid Change As well as visualize and Quantify That Change.</p>
          </div>
            <div className="company-icon"> <img className="company-logo-small logo-one" src={sdgLogoSmall} /> </div>
            <img className="company-logo-large" src={sdgLogoLarge} />
            <img className="company-logo-small logo-two" src={sdgLogoSmall} />
            <img className="company-logo-small logo-three" src={sdgLogoSmall} />

          <div className="header-search">
          <Search  history={props.history} placeholder="Find Companies, read their goals. Track thier SDG's"/>
          </div>

        </div>
      </section>

      <section className="companies-list-item">

        <div className="company-icon">
          <img className="company-img" src={buildingImg} />
        </div>
        <div className="company-text">
          <h4> Over 1,000,000 Companies Listed </h4>
          <p className="text"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua </p>
        </div>
        <div className="learn-more-btn">
          <button className="learn-btn">Learn More</button>
        </div>
      </section>

      <section className="about-leaf">
        <div className="about-text">
          <h2 className="subhead">Who Is Leaf</h2>
            <p> Leaf is powered by an open-sourced database of U.S.C.S. certified sustainable goods & a matchmaking engine. Transparency is built in and powered by a decentralized supply chain for increased accountability & matchmaking
              engine that leads companies to the right products for their exact sustainability needs.
          </p>
          <div className="btn-wrapper">
            <Button type='button' text="Join Today"/>
          </div>
        </div>
      </section>

      <section className="featured-companies">
        <div className="about-text">
          <h2 className="subhead">Featured Companies</h2>
            <p> Learn More about companies that are changing the shape of humanity via Sustainable Development Goals </p>

        </div>

          { companies.length &&  getCompanies(companies) }


           
        <div className="btn-wrapper">
          <Button type="button" text="View All Sectors" />
        </div>
      </section>

    </div>
  );
};

export default Landing;
