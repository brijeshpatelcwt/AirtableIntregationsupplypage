import React from 'react'

import AdminLayout from '../../../Components/Admin/AdminLayout/AdminLayout'
import Octicon, { Search, ChevronDown, ChevronRight, IssueClosed, KebabVertical, Pencil, PrimitiveDot, ChevronLeft, Settings } from '@primer/octicons-react'
import DefaultCard, {Body, Header, Footer} from '../../../Components/Admin/DefaultCard/DefaultCard'
import './LatestUpdate.css'
import { Link } from 'react-router-dom'

import { Button, Form } from 'react-bootstrap';
const LatestUpdate = props => {
  return (
      <AdminLayout history={props.history}>
        <div className="w-100 row">&nbsp;</div>
        <div className="row latest-update col-12">
          <div className="row ml-0 mr-2">
            <Button className="button bg-white text-secondary" size="sm"> 
            <Octicon icon={Settings} className="text-secondary" /> 
            &nbsp; &nbsp; FILTER</Button>
          </div>
          <div className="row m-0 col-6">
            <Octicon icon={Search} className="icon text-secondary" />
            <input className="search font-10" placeholder="Search logs" />
          </div> 
        </div>
        <div className="w-100 row">&nbsp;</div>
        <div className="row">
        <DefaultCard className="col-12">
            <Body>
              <div className="row justify-content-between font-12">
                <div className="col-4 pt-1">
                  Latest Updates
                  <span className="text-secondary pl-3 font-10">3200 total</span>
                </div>
              </div>
              <div className="table-responsive mt-2">
                <table className="table table-hover font-10">
                  <tbody>
                  <tr>
                      <td>Activity ID</td>
                      <td>Company</td>
                      <td>Date</td>
                      <td>Status</td>
                      <td>Action</td>
                    </tr>

                    <tr>
                      <td>23456789-2</td>
                      <td>Facebook</td>
                      <td>02/01/2020</td>
                      <td> 
                        <Octicon icon={PrimitiveDot} className="text-success" /> &nbsp; Successful
                      </td>
                      <td className="text-secondary">
                        <Octicon icon={KebabVertical} />
                        &nbsp; &nbsp;
                        <Octicon icon={Pencil} />
                      </td>
                    </tr>
                    <tr>
                      <td>23456789-2</td>
                      <td>Apple</td>
                      <td>02/01/2020</td>
                      <td> 
                        <Octicon icon={PrimitiveDot} className="text-warning" /> &nbsp; Pending
                      </td>
                      <td className="text-secondary">
                        <Octicon icon={KebabVertical} />
                        &nbsp; &nbsp;
                        <Octicon icon={Pencil} />
                      </td>
                    </tr>
                    <tr>
                      <td>23456789-2</td>
                      <td>Google</td>
                      <td>02/01/2020</td>
                      <td> 
                        <Octicon icon={PrimitiveDot} className="text-danger" /> &nbsp; Failed
                      </td>
                      <td className="text-secondary">
                        <Octicon icon={KebabVertical} />
                        &nbsp; &nbsp;
                        <Octicon icon={Pencil} />
                      </td>
                    </tr>
                    <tr>
                      <td>23456789-2</td>
                      <td>Microsoft</td>
                      <td>02/01/2020</td>
                      <td> 
                        <Octicon icon={PrimitiveDot} className="text-success" /> &nbsp; Successful
                      </td>
                      <td className="text-secondary">
                        <Octicon icon={KebabVertical} />
                        &nbsp; &nbsp;
                        <Octicon icon={Pencil} />
                      </td>
                    </tr>
                    <tr>
                      <td>23456789-2</td>
                      <td>EmmsDan</td>
                      <td>01/01/2020</td>
                      <td> 
                        <Octicon icon={PrimitiveDot} className="text-success" /> &nbsp; Successful
                      </td>
                      <td className="text-secondary">
                        <Octicon icon={KebabVertical} />
                        &nbsp; &nbsp;
                        <Octicon icon={Pencil} />
                      </td>
                    </tr>

                  </tbody>
                </table>
              </div>

              <div className="row font-10 justify-content-end">
                  <div className="col-4 row justify-content-end">
                    <div className="col-7 row justify-content-end text-right font-10 pt-3"> Rows per page </div>
                    <Form.Control className="col-4 m-1 cursor-pointer" as="select">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </Form.Control>
                  </div>
                  <div className="col-2 pr-3 text-right">
                    <br />
                  1  &nbsp;- &nbsp;10 &nbsp; of &nbsp; 100 
                  &nbsp;  &nbsp; &nbsp;
                  <Octicon icon={ChevronLeft} className="cursor-pointer" />
                  &nbsp; &nbsp; &nbsp;
                  <Octicon icon={ChevronRight} className="cursor-pointer" />

                  </div>
              </div>
            </Body>
          </DefaultCard>
        
        </div>
       </AdminLayout>
  )
}

LatestUpdate.propTypes = {

}

export default LatestUpdate

