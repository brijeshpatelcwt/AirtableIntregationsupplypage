import React from 'react'
import Octicon, { Search } from '@primer/octicons-react'

import AdminLayout from '../../../Components/Admin/AdminLayout/AdminLayout'

import SlackLogo from '../../../Assets/Images/logos/slack.png';
import GithubLogo from '../../../Assets/Images/logos/github.png';
import MediumLogo from '../../../Assets/Images/logos/medium.png';
import SquarespaceLogo from '../../../Assets/Images/logos/squarespace.png';
import DropBoxLogo from '../../../Assets/Images/logos/dropbox.png';
import LyftLogo from '../../../Assets/Images/logos/lya.png';
import CompanyProfileCard from '../../../Components/Admin/CompanyProfileCard/CompanyProfileCard'
import './CompanyProfiles.css'
import { Button } from 'react-bootstrap';
const CompanyProfiles = props => {
  return (
      <AdminLayout history={props.history}>
        <div className="w-100 row">&nbsp;</div>
        <div className="row company-profile justify-content-between">
          <div className="col-8 ml-1">
            <Octicon icon={Search} className="icon text-secondary" />
            <input className="search font-10" placeholder="Search users by name" />
          </div>
          <div className="col-3 row  justify-content-end mr-0">
            <Button className="button" size="sm"> ADD NEW</Button>
          </div>
        </div>
        <div className="w-100 row">&nbsp;</div>
        <div className="row">
          <CompanyProfileCard
            company="DropBox"
            logo={DropBoxLogo}
            info="Dropbox is a file hosting service that offers cloud storage, file synchronization, a personal cloud."
            lastUpdate="2 hr ago"
            className="col-4" />
          <CompanyProfileCard
            company="Medium Corporation"
            logo={MediumLogo}
            info="Medium is an online publishing platform developed by Evan Williams, and launched in August 2012."
            lastUpdate="1 hr ago"
            className="col-4" />
          <CompanyProfileCard
            company="Slack"
            logo={SlackLogo}
            info="Slack is a cloud-based set of team collaboration tools and services, founded by Stewart Butterfield."
            lastUpdate="2 years ago"
            className="col-4" />
          <CompanyProfileCard
            company="Lyft"
            logo={LyftLogo}
            info="Lyft is an on-demand transportation company based in San Francisco, California."
            lastUpdate="2 hr ago"
            className="col-4" />
          <CompanyProfileCard
            company="Github"
            logo={GithubLogo}
            info="GitHub is a web-based hosting service for version control of code using Git."
            lastUpdate="2 hr ago"
            className="col-4" />
          <CompanyProfileCard
            company="Squarespace"
            logo={SquarespaceLogo}
            info="Squarespace provides software as a service for website building and hosting. Headquartered in NYC."
            lastUpdate="2 hr ago"
            className="col-4" />
         </div>
      </AdminLayout>
  )
}

CompanyProfiles.propTypes = {

}

export default CompanyProfiles

