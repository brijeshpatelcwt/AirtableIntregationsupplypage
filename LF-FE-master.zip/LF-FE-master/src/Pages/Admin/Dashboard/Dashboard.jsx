import React from 'react'
import PropTypes from 'prop-types'
import AdminLayout from '../../../Components/Admin/AdminLayout/AdminLayout'
import ChartCard from '../../../Components/Admin/ChartCard/ChartCard'
import Octicon, { Pulse, Organization, Hubot, ChevronDown, ChevronRight, IssueClosed, KebabVertical, Pencil, PrimitiveDot, ChevronLeft } from '@primer/octicons-react'
import DefaultCard, {Body, Header, Footer} from '../../../Components/Admin/DefaultCard/DefaultCard'
import { Link } from 'react-router-dom'
import { Doughnut, Bar } from 'react-chartjs-2'
import ProfileIcon from '../../../Components/ProfileCard/ProfileIcon'
import SlackLogo from '../../../Assets/Images/logos/slack.png';
import GithubLogo from '../../../Assets/Images/logos/github.png';
import DropBoxLogo from '../../../Assets/Images/logos/dropbox.png';
import lyALogo from '../../../Assets/Images/logos/lya.png';
import { Button, Form } from 'react-bootstrap'
import { useState } from 'react'
import { searchCompany } from '../../../services/companies'
import { getPercent } from '../../../utils'

import Amplify, { Auth, API } from 'aws-amplify';
import { withAuthenticator } from 'aws-amplify-react';
import awsconfig from '../../../aws-exports';
Amplify.configure(awsconfig);
const data = {
  label: [22, 63, 15],
	datasets: [{
		data: [22, 63, 15],
		backgroundColor: [
		'#EC4C47',
		'#1070CA',
		'#F7D154'
		],
		hoverBackgroundColor: [
		'#FF6384',
		'#36A2EB',
		'#FFCE56'
		]
	}]
};
const barData =  {
  labels: ["1 Aug", "2 Aug", "3 Aug", "4 Aug" ],
  datasets: [
    {
      label: '',
      backgroundColor: '#1665D8',
      borderWidth: 1,
      barThickness: 8,
      hoverBackgroundColor: '#EDF0F2',
      hoverBorderColor: '#1665D8',
      data: [165, 219, 180, 155, 356, 160, 220]
    },{
      label: '',
      backgroundColor: '#EDF0F2',
      borderWidth: 1,
      barThickness: 8,
      hoverBackgroundColor: '#1665D8',
      hoverBorderColor: '#EDF0F2',
      data: [175, 199, 160, 145, 296, 100, 190]
    }
  ]
}
let nextToken;

async function listEditors(limit){
  let apiName = 'AdminQueries';
  let path = '/listUsersInGroup';
  let myInit = {
      queryStringParameters: {
        "limit": 22,
        "token": nextToken
      },
      headers: {
        'Content-Type' : 'application/json',
        Authorization: `${(await Auth.currentSession()).getAccessToken().getJwtToken()}`
      }
  }
  const { NextToken, ...rest } =  await API.get(apiName, path, myInit);
  nextToken = NextToken;
  return rest;
}
const AdminDashboard = props => {
  const [ totalCompany, setTotalCompany ] = useState(0);
  const [ totalActiveCompany, setTotalActiveCompany ] = useState(0);
  const [ totalMileStoreCompany, setTotalMileStoreCompany ] = useState(0);
  const [ totalMileStoreSetCompany, setTotalMileStoreSetCompany ] = useState(0);
  const [ totalMileStones, setTotalMileStones ] = useState(0);
  if (!totalCompany) {
    searchCompany('', 100000)
    .then(res => {
      const total = res.length;
      const active =  res.filter(r => r?.Company.toLowerCase().search('test') === -1).length;
      const withMilestone = res.filter(res =>  res['Milestone Targets']).length
      const withMilestone2 = res.filter(res =>  res['Milestones Acheived']).length
      setTotalMileStones(res.filter(res =>  res['Milestones Acheived'] || res['Milestone Targets']).length)
      setTotalCompany(active)
      setTotalActiveCompany(getPercent(total, active));
      setTotalMileStoreCompany(getPercent(total, withMilestone))
      setTotalMileStoreSetCompany(withMilestone2)
    });
  }
  const labelBox = data.label.map((item, ind) => {
    const lStyled = {
      color: data.datasets[0].backgroundColor[ind],
      fontWeight: 'bold'
    }
    return <div className="col" style={lStyled}>{item + "%"}</div>
  });
  return (
      <AdminLayout history={props.history}>
        <div className="row">
          <ChartCard
            className="col"
            total={totalMileStones}
            title="global targets"
            percent="10%"
            lastUpdate=" 6 years ago"
            Icon={Hubot}
          />
          <ChartCard
            className="col"
            total={totalMileStoreSetCompany}
            title="SDG milestones set"
            percent={totalMileStoreCompany + "%"}
            lastUpdate="last month"
            Icon={Organization}
          />
          <ChartCard
            className="col"
            total="75,5%"
            title="overall progress"
            progress="80%"
            Icon={Pulse}
          />
          <ChartCard
            className="col active"
            total={totalCompany}
            title="total active companies"
            percent={totalActiveCompany + "%"}
            lastUpdate="2 months ago"
            />
        </div>
        <div className="row">
          <DefaultCard className="col-9">

            <Header>
              <div className="row font-10">
                <div className="col">User sign up info</div>
                <div className="col-3 row justify-content-end pr-4">
                  Last 7 days &nbsp; <Octicon icon={ChevronDown} />
                </div>
              </div>
            </Header>
            <Body>
            <Bar
          data={barData}
          height={239}
          options={{
            maintainAspectRatio: false
          }}
        />
            </Body>

            <Footer>
              <div className="row font-10 justify-content-end pr-2">
              <Link to="overview">
              Audience Overview <Octicon icon={ChevronRight} />
              </Link>
              </div>
            </Footer>
          </DefaultCard>
          <DefaultCard className="col-3">
          <Header>
              <div className="row font-10">
                <div className="col">SDG Info</div>
                <div className="col-3 row justify-content-end pr-4 text-secondary">
                  <Octicon icon={IssueClosed} />
                </div>
              </div>
            </Header>
            <Body>
              <Doughnut
                data={data}
                width={50}
                height={50}
              />
              <br />
              <div className="row">
              {labelBox}
              </div>
            </Body>
            <Footer>
              <div className="row font-8">
                <div className="col">
                  Last 7 days <Octicon icon={ChevronDown} />
                </div>
                <div className="col-7 row justify-content-end pr-4">
                  <Link to="overview">
                  Audience Overview <Octicon icon={ChevronRight} />
                  </Link>
                </div>
              </div>
            </Footer>
          </DefaultCard>
        </div>
        <div className="w-100 row">&nbsp;</div>
        <div className="row">
          <DefaultCard className="col-3">
            <Body>
              <div className="mb-2">Latest Companies</div>
              <ProfileIcon
                title="DropBox"
                subtitle="updated 5hrs ago"
                image={DropBoxLogo}
                moreUrl={true}
              />
              <ProfileIcon
                title="Medium Corporation"
                subtitle="updated 5hrs ago"
                image={lyALogo}
                moreUrl={true}
              />
              <ProfileIcon
                title="Github"
                subtitle="updated 5hrs ago"
                image={GithubLogo}
                moreUrl={true}
              />
              <ProfileIcon
                title="Slack"
                subtitle="updated 5hrs ago"
                image={SlackLogo}
                moreUrl={true}
              />
            </Body>
            <Footer>
                <div className="row font-10 justify-content-end pr-4">
                  <Link to="overview">
                  View all <Octicon icon={ChevronRight} />
                  </Link>
                </div>
            </Footer>
          </DefaultCard>
          <DefaultCard className="col-9">
            <Body>
              <div className="row justify-content-between font-12">
                <div className="col-4 pt-1">
                  Latest Updates
                  <span className="text-secondary pl-3 font-10">3200 total</span>
                </div>
                <div className="col-5 row justify-content-end mr-0">
                  <div className="pt-1">
                  Sort by: Newest
                  &nbsp; <Octicon icon={ChevronDown} /> &nbsp;&nbsp;</div>
                  <Link to="/admin/latest-update">
                    <Button variant="outline-primary" size="sm" className="font-10">NEW ENTRY</Button>
                  </Link>
                </div>
              </div>
              <div className="table-responsive mt-2">
                <table className="table table-hover font-10">
                  <tbody>
                  <tr>
                      <td>Activity ID</td>
                      <td>Company</td>
                      <td>Date</td>
                      <td>Status</td>
                      <td>Action</td>
                    </tr>

                    <tr>
                      <td>23456789-2</td>
                      <td>Facebook</td>
                      <td>02/01/2020</td>
                      <td>
                        <Octicon icon={PrimitiveDot} className="text-success" /> &nbsp; Successful
                      </td>
                      <td className="text-secondary">
                        <Octicon icon={KebabVertical} />
                        &nbsp; &nbsp;
                        <Octicon icon={Pencil} />
                      </td>
                    </tr>
                    <tr>
                      <td>23456789-2</td>
                      <td>Apple</td>
                      <td>02/01/2020</td>
                      <td>
                        <Octicon icon={PrimitiveDot} className="text-warning" /> &nbsp; Pending
                      </td>
                      <td className="text-secondary">
                        <Octicon icon={KebabVertical} />
                        &nbsp; &nbsp;
                        <Octicon icon={Pencil} />
                      </td>
                    </tr>
                    <tr>
                      <td>23456789-2</td>
                      <td>Google</td>
                      <td>02/01/2020</td>
                      <td>
                        <Octicon icon={PrimitiveDot} className="text-danger" /> &nbsp; Failed
                      </td>
                      <td className="text-secondary">
                        <Octicon icon={KebabVertical} />
                        &nbsp; &nbsp;
                        <Octicon icon={Pencil} />
                      </td>
                    </tr>
                    <tr>
                      <td>23456789-2</td>
                      <td>Microsoft</td>
                      <td>02/01/2020</td>
                      <td>
                        <Octicon icon={PrimitiveDot} className="text-success" /> &nbsp; Successful
                      </td>
                      <td className="text-secondary">
                        <Octicon icon={KebabVertical} />
                        &nbsp; &nbsp;
                        <Octicon icon={Pencil} />
                      </td>
                    </tr>
                    <tr>
                      <td>23456789-2</td>
                      <td>EmmsDan</td>
                      <td>01/01/2020</td>
                      <td>
                        <Octicon icon={PrimitiveDot} className="text-success" /> &nbsp; Successful
                      </td>
                      <td className="text-secondary">
                        <Octicon icon={KebabVertical} />
                        &nbsp; &nbsp;
                        <Octicon icon={Pencil} />
                      </td>
                    </tr>

                  </tbody>
                </table>
              </div>

              <div className="row font-10 justify-content-end ml-5 pl-5">
                  <div className="col-4 row justify-content-end">
                    <div className="col-7 text-right font-10 p-0 m-0">
                    <div className="m-3 p-0"></div>
                    Rows per page </div>
                    <Form.Control className="col-4 m-1 cursor-pointer" as="select">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </Form.Control>
                  </div>
                  <div className="col-3">
                    <br />
                  1  &nbsp;- &nbsp;10 &nbsp; of &nbsp; 100
                  &nbsp;  &nbsp; &nbsp;
                  <Octicon icon={ChevronLeft} className="cursor-pointer" />
                  &nbsp; &nbsp; &nbsp;
                  <Octicon icon={ChevronRight} className="cursor-pointer" />

                  </div>
                </div>
            </Body>
          </DefaultCard>
        </div>
      </AdminLayout>
  )
}

AdminDashboard.propTypes = {

}

export default AdminDashboard
