import React, { useRef, useState, useEffect } from 'react';
import { Auth } from 'aws-amplify';

import isEmail from 'validator/lib/isEmail';
import Header from '../../Components/Header/Header';
import './Login.css';
import { Button } from 'react-bootstrap';
import { Link, Redirect } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { loginToAdmin, loginToAccount } from '../../redux/reducer/generalReducer';
import { SignIn } from '../../services/login';

const Login = (props) => {
	const dispatch = useDispatch();
	const [ isLoading, setIsLoading ] = useState(false);
	const [ isSubmitting, setIsSubmitting ] = useState({ disabled: false, text: 'Login' });
	const [ error, setError ] = useState('');
	const [ isEmailValid, setIsEmailValid ] = useState('');
	const [ isPasswordValid, setIsPasswordValid ] = useState('');
	const [ passwordType, setPasswordType ] = useState('password');
	const passwordInput = useRef({});
	const emailInput = useRef({});

	const validateEmail = ({ target: { value } }) => {
		const isValid =
			isEmail(value) ? 'success' :
			'danger';
		setIsEmailValid(isValid);
	};
	const validatePassword = ({ target: { value } }) => {
		const isValid =

				value.length > 4 ? 'success' :
				'danger';
		setIsPasswordValid(isValid);
	};
	const passwordLabel =

			passwordType !== 'text' ? 'Show Password' :
			'Hide Password';
	const showPassword = () => {
		if (passwordType === 'text') {
			setPasswordType('password');
		} else {
			setPasswordType('text');
		}
	};
	const disabled = () => {
		const emptyFields = isEmailValid !== 'success' || isPasswordValid !== 'success';
		return emptyFields || isSubmitting.disabled;
	};
	const loginButton = {
		className: 'button',
		disabled: disabled()
	};
	const submitForm = async () => {
		if (isSubmitting.disabled) return;
		setError('');
		setIsSubmitting({ disabled: true, text: 'Submitting Form...' });
		const user = await SignIn({ username: emailInput.current.value, password: passwordInput.current.value });

		if (user.code) {
			setError(user.message);
			setIsSubmitting({ disabled: false, text: 'Login Again' });
		} else {
			dispatch(loginToAccount(user.idToken));
			console.log(user);
			props.history.push(
					user.idToken.payload['custom:role'] === 'admin' ? './admin/dashboard' :
					'./company/dashboard'
			  );
		}
	};

	return (
		<div>
			<Header />
			<div className="row align-items-center justify-content-center login-wrapper">
				<div className="login">
					<div className="login-header">
						Login to <strong>LEAF</strong>
						{error && <div className="text-danger">{error}</div>}
					</div>

					<input
						type="email"
						className={isEmailValid}
						onKeyUp={validateEmail}
						placeholder="Work Email"
						ref={emailInput}
					/>
					<input
						type={passwordType}
						className={isPasswordValid}
						onKeyUp={validatePassword}
						placeholder="Password"
						ref={passwordInput}
					/>

					<div className="row justify-content-between mb-2">
						<div className="col">
							<label>
								<Link to="/forgot-password" className="text-dark">
									Forgot Password?
								</Link>
							</label>
						</div>
						<div className="col text-right cursor-pointer" onClick={showPassword}>
							<label className="cursor-pointer">{passwordLabel}</label>
						</div>
					</div>
					<div className="mt-4 mb-4">
						<Button {...loginButton} onClick={submitForm} block size="lg">
							{isSubmitting.text}
						</Button>
					</div>

					<div className="text-center">
						<label>
							Don't have a LEAF account?
							<Link to="/create-account">
								<strong className="text-success"> &nbsp; Sign Up for free now</strong>
							</Link>
						</label>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Login;
