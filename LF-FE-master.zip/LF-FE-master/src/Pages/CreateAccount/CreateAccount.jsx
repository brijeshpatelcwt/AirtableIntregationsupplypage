import React, { Component, useState, useRef } from 'react';
import Header from '../../Components/Header/Header';
import './CreateAccount.css';
import InputBox from '../../Components/InputBox/InputBox';
import SDGLOGO from '../../Assets/Images/SDG-Logo-PNG 5.png';
import { Button } from 'react-bootstrap';
import { Footer } from '../../Components/Footer/Footer';
import { Redirect, Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import isEmail from 'validator/lib/isEmail';

import { CreateAccount } from '../../services/createaccount';
import { createCompanyAccount } from '../../redux/reducer/generalReducer';

const Register = (props) => {

  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState({disabled: false, text: 'Submit'});
  const [ passwordType, setPasswordType ] = useState('password');
  const nameInput = useRef({});
  const websiteInput = useRef({});
  const emailInput = useRef({});
  const passwordInput = useRef({});

  const passwordLabel = passwordType !== 'text' ? 'Show Password' : 'Hide Password';
  const showPassword = () => { 
    if (passwordType === 'text') {
      setPasswordType('password');
    } else {
      setPasswordType('text');
    }
  }

  const submitForm = async () => {
    if (isSubmitting.disabled) return;
    setIsSubmitting({ disabled: true, text: 'Submitting Form...'})
    const user = await CreateAccount({ 
        name: nameInput.current.value,
        email: emailInput.current.value,
        password: passwordInput.current.value,
        website: websiteInput.current.value,
    })
    if (user.code) {
        setError(user.message)
        setIsSubmitting({ disabled: false, text: 'Submit Again'})
    } else {
      alert('You Account has been Created, Please confirm your account, to continue')
      dispatch(createCompanyAccount(user.idToken));
      props.history.push('./login');
    }
  }
    const createAccount = (e) => <Redirect to='/company/setup'/>
        return (
            <>
            <Header/>
            <div className="App">
            <div className="register">
             <div className="container">
             <div className="row">
            <div className="col-sm-7">
            <div className="register-col-one">
            <img src={SDGLOGO} alt="sdg_logo"/>
            </div>
            <div className="list">
            <p className="intro-title">A seamless way to track your SDGs</p>
            <ul className="track-list">
             <li>Track your progress on SDGs and company goals</li> 
             <li>Conect with potential partners in your sector that can benefit your supply chain</li> 
             <li>See where you stand and compare your company to other companies</li>       
            </ul>    
            </div>
            </div>   
            <div className="col-sm-5">
            <p>Create a Free Account</p>
            { error && <div className="text-danger">{error}</div>}
            <form>
                <div className="input_box">
                    <input ref={nameInput} placeholder="Akinyele Dairo"/> 
                </div>
                <div className="input_box">
                    <input type="text" ref={websiteInput} placeholder="https://apple.com" /> 
                </div>
                <div className="input_box">
                    <input type="email" ref={emailInput} placeholder="Email" /> 
                </div>
                <div className="input_box">
                    <input type={passwordType} ref={passwordInput} placeholder="password" /> 
                <div className="col text-right cursor-pointer" onClick={showPassword}>
                  <label className="cursor-pointer font-10 text-primary">{passwordLabel}</label>
                </div>
                </div>
            <div className="register-btn-wrapper">
                
            <Button disabled={ isSubmitting.disabled } className="button" onClick={ submitForm } block size="lg">
              { isSubmitting.text }
            </Button>
            <p className="register-login">Already have a LEAF account? <span style={{ fontWeight:"bold" }}>Log in here now</span></p>
            </div>
            </form>
            </div>     
            </div>    
            </div>   
            </div>
            <Footer/>
            </div>
            </>
        )
    }

export default Register
