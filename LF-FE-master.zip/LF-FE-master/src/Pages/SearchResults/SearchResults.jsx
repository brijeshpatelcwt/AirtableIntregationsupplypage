import React, { Component } from 'react';
import Loader from 'react-loader-spinner';
import * as Icons from '@fortawesome/free-brands-svg-icons';

import './SearchResults.css';
import Search from '../../Components/Search/Search';
import Header from '../../Components/Header/Header';
import CheckBox from '../../Components/Shared/CheckBox/CheckBox';
import SearchResultsCard from '../../Components/SearchResultsCard/SearchResultsCard';
import Companies from '../../Assets/json/companies.json';

import {getAllSectors} from '../../services/sector';
import {searchCompany} from '../../services/companies';
const ListSectors = () => {
    return <h1> </h1>
}

class SearchResults extends Component {
    constructor(props) {
        super(props)
        this.search = this.props.history.location.hash.replace('#?search=', '');
        this.state = {}
    }
    componentDidMount() {
      window.scrollTo(0, 0)
      if(!this.state.companies) {
        searchCompany(this.search)
          .then(res => this.setState({ companies: res }))
      }
    }
    componentDidUpdate() {
    }
    getCompanies() {
    getAllSectors();
        return this.state.companies ? this.state.companies.map((item, key) => {
            return <SearchResultsCard
                url={item.id}
                key={key}
                title={item.Company}
                body={item.Bio || ''}
                logo={item.Logo[0].thumbnails.large.url || (Icons[`fa${item.Company}`]  || Icons[`faEnvira`])}
              />;
        }) : <></>;
    }
    handleChange(search, state=this) {
        state.setState({})
        searchCompany(search)
            .then(res => state.setState({ companies: res }))
            .catch(err => console.log(err))
    }
    render() {
        return (
            <>
              <Header/>
            <div className="search-results">
            <header className="header masthead">
            <div className="overlay"></div>
            <div className="container">
            <div className="row header-text">
            <div className="col">
            <p className="search-results-header-title">Search Results for {this.search || ''}</p>
            <span className="search-results-header-span">Find Companies. Read their goals. Track SDGs.</span>
            <Search handleChange={this.handleChange}  state={this} defaultValue={this.search} history={this.props.history} placeholder="Find Companies, read their goals. Track thier SDG's"/>
            </div>
            </div>
            </div>
        </header>

        <section>

        <div className="row">
        <div className="col-sm-3 sectors">
        <p>Sectors</p>
        <ListSectors />

        <p>SDGs</p>
        <CheckBox title="SDG 1"/>
        <CheckBox title="SDG 2"/>
        </div>
        <div className="col-sm-9">
        <div className="row results">

       {
           this.state.companies ? this.state.companies.length ? this.getCompanies() : <h2> Search Result Not Found</h2> :
           <Loader
               type="Oval"
               color="#60a112"
               height={100}
               width={200}
               timeout={0}
           />
       }

      </div>
        </div>
        </div>

        </section>
            </div>
            </>
        )
    }
}

export default SearchResults
