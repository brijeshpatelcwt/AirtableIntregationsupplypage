import React from 'react';
import Card from '../../../../Components/companyDashBoardCard/Card';
//graph imports
import dropdown_rise from '../../../../Assets/Images/rise.png';
import graph_blue from '../../../../Assets/Images/graph_blue.png';
import graph_green from '../../../../Assets/Images/graph_green.png';

//icons for top performing
import FbIcon from '../../../../Assets/Images/fb_icon_325x3251.png';
import AppleIcon from '../../../../Assets/Images/apple.png';
import Pepsico from '../../../../Assets/Images/pepsi.png';
import { Link, withRouter } from 'react-router-dom'

const Supply = (props) => {
    console.log(props)
    return (
        <>
        <div className="row">
        <Card rating="- 0,1" title="Overall Sector Progress" percent="20%" dropdown={dropdown_rise} graph={graph_blue} index="performance index"/>
        <Card rating="+ 2,4" title="Supply Chain Partnerships" percent="20" dropdown={dropdown_rise} graph={graph_green} index="partner index"/>
        <Card border={true} rating="+ 2,4" title="My Company Ranking" percent="8th" dropdown={dropdown_rise}  index="out of 1,230"/>
        </div>   

        <div className="company-setup-card" style={{paddingRight:"70px",paddingLeft:"70px"}}>
        <p>Sector Info</p>
        <div className="divider" style={{marginLeft:"-70px"}}></div>
        <p className="sector-info-p">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod  tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim  veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea  commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p> 
   
   {/* Top performing sdgs */}
        <div className="three-title-box">
             <p>Top Performing Companies</p> 
             <a className="all-rankings" href="#">View All</a>  
        </div>
        
        <div className="row" style={{marginLeft:"0"}}>
         <TopPerformers location={props.location} image={FbIcon} company="Facebook"/> 
         <TopPerformers location={props.location} image={AppleIcon} company="Apple inc"/>  
         <TopPerformers location={props.location} image={Pepsico} company="Pepsico"/> 
         <TopPerformers location={props.location} image={FbIcon} company="Facebook"/> 
         <TopPerformers location={props.location} image={FbIcon} company="Facebook"/>  
        </div>
         {/* Top performing sdgs  end*/}

        {/* Companies with similar CSRs start */}
        <div className="three-title-box" style={{marginTop:"160px"}}>
             <p>Companies with similar CSRs</p> 
             <a className="all-rankings" href="#">View All</a>  
        </div>
        <div className="row" style={{marginLeft:"0"}}>
         <TopPerformers location={props.location} image={FbIcon} company="Facebook"/> 
         <TopPerformers location={props.location} image={AppleIcon} company="Apple inc"/>  
         <TopPerformers location={props.location} image={Pepsico} company="Pepsico"/> 
         <TopPerformers location={props.location} image={FbIcon} company="Facebook"/> 
         <TopPerformers location={props.location} image={FbIcon} company="Facebook"/>  
        </div>
         {/* Companies with similar CSRs  end*/}
        </div>   
        </>
    )
}

export default Supply;

const TopPerformers = ({image,company,match}) => {
    console.log(match)
    return (
        <div className="col company_cards">
        <div className="company-bg">
       <img src={image} height="60"  alt="sdg logo"/>  
        </div>
        <p className="company">{company}</p>
        <button className="connect"><Link to={`/company/dashboard/supply-chain/connect`}>Connect</Link></button>
        </div>
    );
}