import React from 'react';
import './supplyChain.css';
import ArrowLeft from '../../../Assets/Images/arrowleft.png';
import {BrowserRouter as Router, Route, Switch } from 'react-router-dom';

//import supply chain pages
import Dashboard from './home/Supply';
import Connect from './connect/Connect';


const supplyChain = (props) => {
    return (
        <Router>
        <div className="company-dashboard-supplychain">
            <p className="supply">Supply Chain</p> 
            <p className="back"><a href="/company/dashboard/supply-chain"><img className="back_icon" src={ArrowLeft} alt="arrow-left"/></a>Back</p> 
            <Switch>
                <Route exact path={props.match.path} component={Dashboard}/>
                <Route exact path="/company/dashboard/supply-chain/connect" component={Connect}/>
            </Switch>
        </div>
        </Router>
    )
}

export default supplyChain;

