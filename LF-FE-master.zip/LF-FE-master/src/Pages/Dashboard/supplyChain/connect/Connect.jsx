import React from 'react';
import { withRouter } from 'react-router-dom';
import FbIcon from '../../../../Assets/Images/fb_icon_325x3251.png';
import AppleIcon from '../../../../Assets/Images/apple.png';
import ArrowLeft from '../../../../Assets/Images/arrow_left.png';
import ArrowRight from '../../../../Assets/Images/arrow_right.png';
import SDG from '../../../CompanySetup/SdgCards/SdgCards';

import Img1 from '../../../../Assets/Images/goals/E-WEB-Goal-01 1.png';
import Img2 from '../../../../Assets/Images/goals/E-WEB-Goal-02 1.png';
import Img3 from '../../../../Assets/Images/goals/E-WEB-Goal-03 1.png';

import Img4 from '../../../../Assets/Images/Rectangle4.png';
import Img5 from '../../../../Assets/Images/Rectangle1.png';
import Img6 from '../../../../Assets/Images/Rectangle 13.png';

import Button from '../../../../Components/Shared/Button/Button';
import './Connect.css';

const Connect = () => {
    return (
        <div className="company-setup-card" style={{paddingRight:"70px",paddingLeft:"70px"}}>
         <p>Connect with Facebook</p>
         <p>Facebook currently engages in all 17 SDGs and has 120 CSRs</p>  
         <div className="company-box">
        <img height="50" alt="company_one" src={AppleIcon}/>
        <div className="arrows">
        <img width="35" src={ArrowLeft} alt="company_two"/>
        <img width="35" src={ArrowRight} alt="company_two"/>
        </div>
        <img height="50" width="50" alt="company_two" src={FbIcon}/>
        </div> 


        <p className="sust-dev-title">Tag applicable SDGs for collaboration</p>
            <div className="sust-dev-goals" style={{marginBottom:"50px"}}>
             <div style={{display:"flex",flexDirection:"row",justifyContent:"space-between"}}>
             <p className="select-sdgs">Select applicable SDGs </p>
            <div className="form-check">
            <label className="form-check-label" style={{marginRight:"25px"}}>
            Select all 17
            </label>
            <input className="form-check-input" type="radio" value="option1"/>
            </div>
            </div>
            <SDG image={Img1} text="Ensure healthy lives and promote well-being for all people" metric="SDG Metric - "/>
            <SDG image={Img2} text="Ensure healthy lives and promote well-being for all people" metric="SDG Metric - "/>
            <SDG image={Img3} text="Ensure healthy lives and promote well-being for all people" metric="SDG Metric - "/>
            </div>
          
            <p className="sust-dev-title">Tag applicable CSRs</p>
            <div className="sust-dev-goals">
            <div style={{display:"flex",flexDirection:"row",justifyContent:"space-between"}}>
            <p className="select-sdgs">Select applicable CSRs  </p>
            <div className="form-check">
            <label className="form-check-label" style={{marginRight:"25px"}}>
            Select all 17
            </label>
            <input className="form-check-input" type="radio" value="option1"/>
            </div>
            </div>
            <SDG image={Img4} text="Ensure healthy lives and promote well-being for all people" metric="SDG Metric - "/>
            <SDG image={Img5} text="Ensure healthy lives and promote well-being for all people" metric="SDG Metric - "/>
            <SDG image={Img6} text="Ensure healthy lives and promote well-being for all people" metric="SDG Metric - "/>
            </div>
           
            <div className="submit-btn-div">
            <Button text="submit"/>
            </div>
            </div>
       
    )
}

export default withRouter(Connect);
