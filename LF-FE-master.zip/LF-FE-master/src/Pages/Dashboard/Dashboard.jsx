import React from 'react';
import Nav from '../../Components/companyDashboardNav/companyDashboardNav';
import Card from '../../Components/companyDashBoardCard/Card';
import {BrowserRouter as Router, Route, Switch, withRouter } from 'react-router-dom';

//import pages
import Dashboard from './companyDashboard/companyDashboard';
import Goals from './Goals/Goals';
import SupplyChain from './supplyChain/supplyChain';
import Footer  from '../../Components/companyDashboardFooter/Footer';

const Companydashboard = (props) => {
    return (
        <Router>
            <Nav/> 
            <div className="company-dashboard">
                <Route exact path={props.match.path} component={Dashboard}/>
                <Route exact path="/company/dashboard/goals" component={Goals}/>
                <Route path="/company/dashboard/supply-chain" component={SupplyChain}/>
                <Footer/>
                </div>
        </Router>
    )
}

export default withRouter(Companydashboard)
