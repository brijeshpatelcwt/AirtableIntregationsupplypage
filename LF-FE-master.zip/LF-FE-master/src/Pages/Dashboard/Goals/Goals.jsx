import React from 'react';
import Plus from '../../..//Assets/Images/plus.png';
import './Goals.css'
import PostCard from '../../CompanyProfile/PostCard/PostCard';
import Octicon, { Pencil,PrimitiveDot } from '@primer/octicons-react';
import img1 from '../../../Assets/Images/Rectangle 12.png';
import img2 from '../../../Assets/Images/Rectangle 13.png';

function Goals() {
    const getGoals = (n) => {
        let arr = [];
        for(let i=1; i<=n; i++){
            arr.push(i)
        }
        if(arr.length !== 0){
            return arr.map(item => {
                // console.log(item)
                    return <img key={item} style={{margin:"23px 20px"}} height="100" width="100"src={require(`../../../Assets/Images/goals/E-WEB-Goal-${item}.png`)} />
                })
        }
    }
    return (
        <>
        <div className="company-dashboard-goals">
        <p className="title">All Company Goals</p>
        <div className="company-setup-card">
        <p>SDG Panel</p>
        <div className="divider"></div> 
        <div className="btn-group btn-group-toggle" data-toggle="buttons">
        <label className="btn btn-secondary active">
            <input type="radio" name="options" id="option1" checked/><Octicon className="dot" icon={PrimitiveDot}/> Active SDGs
        </label>
        <label className="btn btn-secondary">
            <input type="radio" name="options" id="option2"/><Octicon className="dot" icon={PrimitiveDot}/> inActive SDGs
        </label>
        </div>
         <div>
            {getGoals(17)}
        </div>  
        </div>
        <div className="company-setup-card">
        <div className="top">
        <p>Company CSR Goals</p>
        <span className="add-new"><img alt="add-new" height="12" width="12" style={{marginRight:"5px"}} src={Plus}/>Add New</span>
        </div>    

        <div className="divider"></div>
        <div className="row">
        <PostCard
        className="goals-post"
        title="Sed ut perspiciatis"
        icon={Pencil}
        content="Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est."
        btn={true}
        goalsPicture={{img1:img1,img2:img2}}
        buttonText="View Details"
        buttonClass="b-button btn-goals"
        />
                <PostCard
        className="goals-post"
        title="Lorem ipsum dolor"
        icon={Pencil}
        content="Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est."
        btn={true}
        goalsPicture={{img1:img1,img2:img2}}
        buttonText="View Details"
        buttonClass="b-button btn-goals"
        />  
                <PostCard
        className="goals-post"
        title="Sed ut perspiciatis"
        icon={Pencil}
        content="Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est."
        btn={true}
        buttonText="View Details"
        buttonClass="b-button btn-goals"
        />  
                <PostCard
        className="goals-post"
        title="Lorem ipsum dolor"
        icon={Pencil}
        content="Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est."
        btn={true}
        buttonText="View Details"
        buttonClass="b-button btn-goals"
        />   
        </div> 
        <div className="divider"></div>
        <div style={{textAlign:"center"}}>
        <button className="view_all">View All CSRs</button> 
        </div>
        </div> 
        </div>
        </>
    )
}

export default Goals;
