import React from 'react';
import './companyDashboard.css';
import Nav from '../../../Components/companyDashboardNav/companyDashboardNav';
import Card from '../../../Components/companyDashBoardCard/Card';

//graph imports
import dropdown_rise from '../../../Assets/Images/rise.png';
import dropdown_fall from '../../../Assets/Images/drop.png';
import graph_red from '../../../Assets/Images/graph.png';
import graph_blue from '../../../Assets/Images/graph_blue.png';
import graph_green from '../../../Assets/Images/graph_green.png';
import rect from '../../../Assets/Images/box.png';
import { Doughnut, Bar,Line } from 'react-chartjs-2'
import Footer from '../../../Components/companyDashboardFooter/Footer';

const companyDashboard = () => {
    const getGoals = (n) => {
        let arr = [];
        for(let i=1; i<=n; i++){
            arr.push(i)
        }
        if(arr.length !== 0){
            return arr.map(item => {
                // console.log(item)
                    return <img key={item} style={{margin:"23px 20px"}} height="100" width="100"src={require(`../../../Assets/Images/goals/E-WEB-Goal-${item}.png`)} />
                })
        }
    }
    const data_doughnut = {
        labels: [
            'Completed',
            'Active',
            'End'
        ],
        datasets: [{
            data: [300, 50, 100],
            backgroundColor: [
            '#2ED47A',
            '#FFB946',
            '#F7685B'
            ],
            hoverBackgroundColor: [
            '#2ED47A',
            '#FFB946',
            '#F7685B'
            ]
        }]
    };
    const data = {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [
          {
            label: 'My First dataset',
            fill: false,
            lineTension: 0.1,
            backgroundColor: 'rgba(75,192,192,0.4)',
            borderColor: 'rgba(75,192,192,1)',
            borderCapStyle: 'butt',
            borderDash: [],
            borderDashOffset: 0.0,
            borderJoinStyle: 'miter',
            pointBorderColor: 'rgba(75,192,192,1)',
            pointBackgroundColor: '#fff',
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBackgroundColor: 'rgba(75,192,192,1)',
            pointHoverBorderColor: 'rgba(220,220,220,1)',
            pointHoverBorderWidth: 2,
            pointRadius: 1,
            pointHitRadius: 10,
            data: [65, 59, 80, 81, 56, 55, 40]
          }
        ]
      };
      
    return (
        <>
            <div className="row">
            <Card rating="+ 0,2" title="No. of SDGs Involved " percent="14" dropdown={dropdown_rise} graph={rect} rect="rect"/>
            <Card rating="- 0,1" title="SDG Progress" percent="30%" dropdown={dropdown_fall} graph={graph_red} index="performance index"/>
            <Card rating="+ 2,4" title="Overall Sector Progress" percent="20%" dropdown={dropdown_rise} graph={graph_blue} index="performance index"/>
            <Card rating="+ 2,4" title="Supply Chain Partnerships" percent="20" dropdown={dropdown_rise} graph={graph_green} index="partner index"/>
            </div>
            <div className="company-setup-card">
            <p className="name">SDGs involved</p>
            <span className="select_more">Select More</span>
            <div>
            {getGoals(17)}
            </div>
            </div>
            <div className="row two"  >
            <div className="col-sm-8">
            <div className="company-setup-card top-performers">
            <div className="table-responsive mt-2">
                <p style={{marginBottom:"20px"}}>Top performers in my sector</p>
                <table className="table table-hover font-10 table-borderless">
                  <tbody>
                  <tr style={{marginBottom:"20px"}}>
                      <td>No</td>
                      <td>Company</td>
                      <td>performance index</td>
                      <td>Middle position</td>
                      <td>Targets achieved</td>
                      <td>Number of SDGs</td>
                    </tr>

                    <tr>
                      <td>1</td>
                      <td>Samsung</td>
                      <td>1,3 <span style={{marginLeft:"20px"}}>+0,2 <img height="10" width="10" src={dropdown_rise}/></span></td>
                      <td>1,2 <span style={{marginLeft:"20px"}}>+0,3 <img height="10" width="10" src={dropdown_rise}/></span></td>
                      <td>
                          <div style={{display:"flex"}}>
                          <span>96%</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "96%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                      </td>
                      <td>
                      <div style={{display:"flex"}}>
                          <span>3</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "30%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                     </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Apple</td>
                      <td>1,8 <span style={{marginLeft:"20px"}}>+0,4 <img height="10" width="10" src={dropdown_rise}/></span></td>
                      <td>1,8 <span style={{marginLeft:"20px"}}>+0,2 <img height="10" width="10" src={dropdown_rise}/></span></td>
                      <td>
                          <div style={{display:"flex"}}>
                          <span>92%</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "92%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                      </td>
                      <td>
                      <div style={{display:"flex"}}>
                          <span>6</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "60%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                     </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Microsoft</td>
                      <td>2,7 <span style={{marginLeft:"20px"}}>2,5</span></td>
                      <td>2,0 <span style={{marginLeft:"20px"}}>1,8</span></td>
                      <td>
                          <div style={{display:"flex"}}>
                          <span>58%</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "75%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                      </td>
                      <td>
                      <div style={{display:"flex"}}>
                          <span>1</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "10%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                     </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>grandauto.us</td>
                      <td>2,8 <span style={{marginLeft:"20px"}}>-0,5 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>2,5 <span style={{marginLeft:"20px"}}>-2,1 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>
                          <div style={{display:"flex"}}>
                          <span>74%</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "75%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                      </td>
                      <td>
                      <div style={{display:"flex"}}>
                          <span>8</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "80%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                     </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>grandauto.us</td>
                      <td>2,8 <span style={{marginLeft:"20px"}}>-0,5 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>2,5 <span style={{marginLeft:"20px"}}>-2,1 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>
                          <div style={{display:"flex"}}>
                          <span>74%</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "75%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                      </td>
                      <td>
                      <div style={{display:"flex"}}>
                          <span>8</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "80%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                     </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>grandauto.us</td>
                      <td>2,8 <span style={{marginLeft:"20px"}}>-0,5 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>2,5 <span style={{marginLeft:"20px"}}>-2,1 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>
                          <div style={{display:"flex"}}>
                          <span>74%</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "75%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                      </td>
                      <td>
                      <div style={{display:"flex"}}>
                          <span>8</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "80%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                     </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>grandauto.us</td>
                      <td>2,8 <span style={{marginLeft:"20px"}}>-0,5 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>2,5 <span style={{marginLeft:"20px"}}>-2,1 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>
                          <div style={{display:"flex"}}>
                          <span>74%</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "75%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                      </td>
                      <td>
                      <div style={{display:"flex"}}>
                          <span>8</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "80%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                     </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>grandauto.us</td>
                      <td>2,8 <span style={{marginLeft:"20px"}}>-0,5 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>2,5 <span style={{marginLeft:"20px"}}>-2,1 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>
                          <div style={{display:"flex"}}>
                          <span>74%</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "75%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                      </td>
                      <td>
                      <div style={{display:"flex"}}>
                          <span>8</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "80%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                     </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>grandauto.us</td>
                      <td>2,8 <span style={{marginLeft:"20px"}}>-0,5 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>2,5 <span style={{marginLeft:"20px"}}>-2,1 <img height="10" width="10" src={dropdown_fall}/></span></td>
                      <td>
                          <div style={{display:"flex"}}>
                          <span>74%</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "75%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                      </td>
                      <td>
                      <div style={{display:"flex"}}>
                          <span>8</span>
                          <div className="progress" style={{width:"80%",marginLeft:"10px", height:"5px",marginTop:"5px"}}>
                          <div className="progress-bar bg-success" role="progressbar" style={{width: "80%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                          </div>
                     </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            </div>
            <div className="col-sm-4">
            <div className="company-setup-card progress-chart">
            <Line data={data} />
            </div>
            <div className="company-setup-card progress-report">
            <Doughnut 
                data={data_doughnut}
              />
            </div>
            </div>
            </div>
           
        </>
    )
}

export default companyDashboard;
