import React from 'react';
import logo from './logo.svg';
import './App.css';
import Header from './Components/Header/Header';
import Landing from './Pages/Landing/Landing';
import { Footer } from './Components/Footer/Footer';

function App(props) {
  return (
    <div className="App">
      <Header props={props}/>
      <Landing props={props} />
      <Footer />
      
    </div>
  );
}

export default App;
