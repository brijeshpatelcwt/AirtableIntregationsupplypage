import React from 'react'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Button from '../../Components/Shared/Button/Button'
import './Footer.css'
import FooterMenu from './FooterMenu.json'
import logo from '../../Assets/logo.png'
import Footerlogo from '../../Assets/Images/uscs-logo-horiziontal 1.png'
import { Link } from 'react-router-dom'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFacebook, faTwitter, faLinkedinIn, faGoogle } from '@fortawesome/free-brands-svg-icons'

const copyRight = `LEAF Inc. ${ new Date().getFullYear() }. All Right Reserved.`
const footerMenu = () => ( FooterMenu.map((menu, key) => (
<Col key={key}>        
  <Link to={menu.url}>
  { 
    menu.title || <img 
      src={logo}
      height="50"
      className="align-top footer-logo d-none d-md-block"
      alt="LEAF LOGO"
    />
  }
  </Link>
</Col>
)))
export const Footer = () => {
 return (
  <div className="container-fluid bg-dark text-light footer">
    <div className="border-bottom border-light">
      {/* <Row>
        { footerMenu() }
      </Row>
    </div>
    <div className="p-4"> &nbsp; &nbsp;</div>
    <div className="icons">
      <span aria-hidden="true"><FontAwesomeIcon icon={faFacebook} /></span>
      <span aria-hidden="true"><FontAwesomeIcon icon={faTwitter} /></span>
      <span aria-hidden="true"><FontAwesomeIcon icon={faLinkedinIn} /></span>
      <span aria-hidden="true"><FontAwesomeIcon icon={faGoogle} /></span>
    </div>
    <div className="copy-right">&#9400; { copyRight } </div>
  </div>
 )
} */}

<Row>
    <Col sm="6" className="logo-col"><img width="70%" src={Footerlogo} alt="LOGO"/></Col>

    <Col sm="6">
        <Row>
            <Col sm="3">
            <Link to="/about-leaf"><h3>About us</h3></Link>
            <ul>
            <Link to="/our-cause"><li>Our Cause</li></Link>
            <Link to="/terms"><li>Terms</li></Link>
            <Link to="/our-cause"><li>Privacy Policy</li></Link>
            </ul>
            </Col>
            <Col sm="3">
            <h3>Community</h3>
            <ul>
            <Link to="/supply-chain"><li>Supply Chain</li></Link>
            <Link to="/leaderboard"><li>Leaderboard</li></Link>
            <Link to="/sdgs"><li>SDGs</li></Link>
            </ul>
            </Col>
            <Col sm="3">
            <h3>Company</h3>
            <ul>
            <Link to="/contact-us"><li>Contact Us</li></Link>
            <Link to="/faq"><li>FAQs</li></Link>
            </ul>
            </Col>
            <Col sm="3">
            <div className="wrapper">
            <button className="btn btn-primary">Register</button>
            <button className="btn btn-primary">Login</button>
            </div>
            </Col>
      </Row>
  </Col>
</Row>
            </div>
            <Col>
            <p className="copyright">© US Coalition, Inc. 2020. All Rights Reserved.</p>
            <div className="social-icons">
            <p className="copyright">Follow us:</p>
                <span aria-hidden="true"><FontAwesomeIcon icon={faFacebook} /></span>
                <span aria-hidden="true"><FontAwesomeIcon icon={faTwitter} /></span>
                <span aria-hidden="true"><FontAwesomeIcon icon={faLinkedinIn} /></span>
                <span aria-hidden="true"><FontAwesomeIcon icon={faGoogle} /></span>
            </div>
            </Col>
  
            </div> 

  )
 }
