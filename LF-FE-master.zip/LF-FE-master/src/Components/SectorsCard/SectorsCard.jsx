import React from 'react';
import './SectorsCard.css';

const SectorsCard = ({icon,impact,amount,Name,color,titleColor}) => {

    return (
        <div className="col-sm-3">
        <div className="sector-card" style={{backgroundColor:`${color}`}}>
        <img src={icon} alt="card icon"/>
        <p className="card-name" style={{color:titleColor}}>{Name}</p>
        <div className="com-impact-box">
        <p className="companies">{amount} companies</p>
        <span>|</span>
        <p className="impact">SDG Impact: {impact}</p>
        </div>
        </div>
        </div>
    )
}

export default SectorsCard;
