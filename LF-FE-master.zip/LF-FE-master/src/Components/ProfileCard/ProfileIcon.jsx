import React from 'react'
import PropTypes from 'prop-types'
import './ProfileStyle.css';
import { Link } from 'react-router-dom';
import Octicon, { KebabVertical } from '@primer/octicons-react';

const ProfileIcon = ({ image, moreUrl, letter, title, subtitle, iconClassName }) => {
  let defaultSideClass = 'col-9 ml-2';
  if (moreUrl) {
    defaultSideClass = 'col-8 ml-1';
  }
  return (<div className="row profile-icon mb-2">
  <div className="col-2">
    {
      image ? <img src={image} alt={image} /> : 
      <div className={"user-icon-wrapper "  + iconClassName}>
        <div className={"user-icon"}>{letter || 's'}</div>
      </div>
    }
  </div>
  <div className={defaultSideClass}>
    <h3 className="m-1">{title || "Emmanuel Daniel"}</h3>
    <h5 className="ml-1"> {subtitle || "emmsdan.inc@gmail.com"}</h5>
  </div>
  {
    !moreUrl || <div className="col-1 mb-4">
      <Link className="text-secondary" to="/more"><Octicon icon={KebabVertical}/></Link>
    </div>
  }
</div>)
};

ProfileIcon.propTypes = {
  bg: PropTypes.string,
  className: PropTypes.string
}

export default ProfileIcon
