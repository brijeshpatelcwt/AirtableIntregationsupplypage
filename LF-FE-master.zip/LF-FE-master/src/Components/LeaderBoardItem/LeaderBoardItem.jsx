import React from 'react';
import './leaderboarditem.css';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const LeaderBoardItem = ({ itemIcon, Name, Score, num, link, className, url }) => {
	return (
		<div className="leaderboard_item">
			<div className="">
				<div className="row">
					<div className="col-sm-2">
						<div className={`box-one ${className}`}>
							<p>{num}</p>
						</div>
					</div>
					<div className="col-sm-10">
						<div className="box-two">
							{/* <FontAwesomeIcon className="icon" icon={itemIcon} /> */}
							<img className="icon" src={url} alt="icon"/>
							<p className="name">
								{Name}
								<br />
								<span className="leaf-score">{Score}</span>
							</p>
							<Link className="link" to={`/company/profile#${Name}`}>
								{link}
							</Link>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default LeaderBoardItem;
