import React from 'react'
import './Header.css';
import NavBar from '../Shared/NavBar';

export default function Header({ bg }) {
  return (<>
    <NavBar />
  </>)
}

