import React from 'react'
import PropTypes from 'prop-types'
import Header from '../Header/Header';
const NotFound404 = ({ children }) => (
  <>
        <Header />
        <div  style={{"height": "90vh"}}>
          <div id="outer">
        <div id="container">
          { children }
        </div>
      </div>
      </div>
  </>
);

export default NotFound404
