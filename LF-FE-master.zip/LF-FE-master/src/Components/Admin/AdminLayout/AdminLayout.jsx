import React from 'react';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';
import { withAuthenticator } from 'aws-amplify-react';

import Header from '../Header/Header';
import SideBar from '../SideBar/Sidebar';

import './AdminLayout.css';
import { Auth } from 'aws-amplify';

const AdminLayout = ({ bg, children, history }) => {
	const defaultState = useSelector((state) => state.default.currentUser.payload);
	if (defaultState || defaultState['custom:role'] !== 'admin') {
		history.push('/company/setup');
	}

	    // console.log(defaultState)
	    // const logOutUser = async () => {
	    //     await Auth.signOut();
	    //     await dispatch(logoutAccount())
	    //     window.location.reload(false);
	    //     props.history.push('/login')
	    // }
	return (
		<div className="container-fluid bg-info">
			<Header />
			<SideBar />
			<div className="container content">
				{children}
				<div className="row m-2"> &nbsp;</div>
				<div className="border-top font-10">
					&copy; &nbsp; LEAF &nbsp; {new Date().getFullYear()} <br />
					<span className="text-secondary font-8">All rights reserved.</span>
				</div>
				<div className="row m-2"> &nbsp;</div>
			</div>
		</div>
	);
};

AdminLayout.propTypes = {
	bg: PropTypes.string,
	children: PropTypes.object
};

export default withAuthenticator(AdminLayout);
