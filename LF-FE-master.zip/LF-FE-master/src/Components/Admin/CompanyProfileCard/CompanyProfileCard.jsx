import React from 'react'
import Octicon, { Clock } from '@primer/octicons-react'
import DefaultCard, {Body, Footer} from '../DefaultCard/DefaultCard'
const CompanyProfileCard = ({ className, logo, company, info, lastUpdate }) => {
  return (
          <DefaultCard className={className}>
            <Body className="row justify-content-center m-2">
              <img src={logo} alt={logo} width="60"/>
              <div className="w-100"></div>
              <div className="mb-2">{company}</div>
              <div className="w-100"></div>
              <div className="mb-2 font-10 text-center text-secondary">
                {info}
              </div>
            </Body>
            <Footer>
                <div className="font-10 text-secondary">
                    <Octicon icon={Clock} /> &nbsp; Updated {lastUpdate}.
                </div>
            </Footer>
          </DefaultCard>
  )
}

CompanyProfileCard.propTypes = {

}

export default CompanyProfileCard

