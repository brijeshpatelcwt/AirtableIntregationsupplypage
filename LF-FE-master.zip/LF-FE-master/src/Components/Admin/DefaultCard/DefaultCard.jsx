import React from 'react'
import PropTypes from 'prop-types'

import './DefaultCard.css'
import { Card } from 'react-bootstrap'

export const Header = ({ className, children }) =>   <Card.Header className={className}>{children}</Card.Header>;
export const Body = ({className, children}) =>   <Card.Body className={className}>{children}</Card.Body>;
export const Footer = ({className, children}) =>   <Card.Footer className={className}>{children}</Card.Footer>;
const DefaultCard = ({ className, children }) => {
  return (<div className={className + " m-0 p-2"}>
    <Card className="default-card">{children}</Card>
</div>)
}

DefaultCard.propTypes = {

}

export default DefaultCard

