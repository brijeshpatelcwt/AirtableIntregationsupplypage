import React from 'react'
import PropTypes from 'prop-types'
import Octicon, { Dashboard, Server, Mail, Person, KebabHorizontal } from '@primer/octicons-react'
import { Navbar } from 'react-bootstrap';
import { useSelector } from 'react-redux'

import './Sidebar.css';
import logo from '../../../Assets/logo.png'
import ProfileIcon from '../../ProfileCard/ProfileIcon';
import { Link, useLocation } from 'react-router-dom';
const isActivePage = (location, page) => {
  if (location.pathname === page) return 'active';
}  

const URL = {
  setting: '/admin/setting',
  dashboard: '/admin/dashboard',
  sdg: '/admin/sdgs',
  cProfile: '/admin/company/profiles',
  chain: '/admin/change'
}
const SideBar = ({ bg, className }) => {
  const adminUser = useSelector(state => state.default.currentUser.payload)
  const location = useLocation();
  return (<div className="sidebar">
    <Navbar bg={ bg || "white"} className={'bg-danger'}>
      <Link to={URL.dashboard}>
        <img src={logo} className="logo m-2" alt="" />
      </Link>
    </Navbar>
    <div className="bg-white m-4">
      <ProfileIcon
        title={adminUser.name || "Akin"}
        letter="A"
        subtitle={adminUser.email}
      />
      <br />
      <ul className="nav flex-column m-2">
        <li className="nav-item">
          <Link to={URL.dashboard} className={isActivePage(location, URL.dashboard) + " nav-link row"}>
            <Octicon icon={Dashboard}/> &nbsp;
            <span className="mt-2 pt-2">Dashboard</span>
          </Link>
        </li>
        <li className="nav-item">
          <Link to={URL.cProfile} className={isActivePage(location, URL.cProfile) + " nav-link row"}>
            <Octicon icon={Server}/> &nbsp;
            <span className="mt-2 pt-2">Company Profiles</span>
          </Link>
        </li>
        <li className="nav-item">
          <Link to={URL.chain} className={isActivePage(location, URL.chain) + " nav-link row"}>
            <Octicon icon={Mail}/> &nbsp;
            <span className="mt-2 pt-2">Supply Chain</span>
          </Link>
        </li>
        <li className="nav-item">
          <Link to={URL.sdg} className={isActivePage(location, URL.sdg) + " nav-link row"}>
            <Octicon icon={Person}/> &nbsp;
            <span className="mt-2 pt-2">SDGs</span>
          </Link>
        </li>

        <li className="nav-item">
          <hr />
        </li>
        <li className="nav-item">
          <Link to={URL.setting} className={isActivePage(location, URL.setting) + " nav-link row"}>
            <Octicon icon={KebabHorizontal}/> &nbsp;
            <span className="mt-2 pt-2">Settings</span>
          </Link>
        </li>
      </ul>
    </div>
    </div>)};

SideBar.propTypes = {
  bg: PropTypes.string,
  className: PropTypes.string
}

export default SideBar
