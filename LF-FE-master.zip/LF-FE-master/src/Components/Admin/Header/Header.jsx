import React from 'react'
import PropTypes from 'prop-types'

import { Navbar } from 'react-bootstrap';

import Octicon, {Search, Bell} from '@primer/octicons-react'
import './Header.css';
const Header = ({ bg, className }) => (
  <Navbar bg={ bg || "white"} expand="sm" className={className + " header"}>
    <Octicon icon={Search} className="icon" />
    <input className="search" placeholder="Global Search..." />
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse className="justify-content-end text-muted">
    <div className="cursor-pointer">
    <Octicon icon={Bell} size="medium" />
    <span className="active-notifiation">.</span>
    </div>
  </Navbar.Collapse>
</Navbar>
);

Header.propTypes = {
  bg: PropTypes.string,
  className: PropTypes.string
}

export default Header
