import React from 'react'
import PropTypes from 'prop-types'
import Octicon, {ChevronUp, GitCompare} from '@primer/octicons-react'

import './ChartCard.css';

const ChartCard = ({ className, title, total, progress, Icon, percent, lastUpdate }) => (
  <div className={className + " row"}>
    <div className="col card m-2 chart-card">
      <div className="row m-0 p-0 top">
        <div className="col-10   p-0">
          <div className="title"> {title}</div>
          <div className="total"> {total}</div>
        </div>
        <div className="col-2 p-0">
          <div className="ml-0 icon row align-content-center justify-content-center">
            <Octicon icon={Icon || GitCompare} />
          </div>
        </div>
      </div>
      { progress ?       
      <div className="progress mt-3" style={{ height: "3px"}}>
        <div className="progress-bar" role="progressbar" style={{width: progress}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
      </div>
      :
      <div className="bottom m-1 row">
        <div className="col-3 m-0 p-0 percent">
          <Octicon icon={ChevronUp} />
          &nbsp; {percent} 
        </div>
        <div className="col m-0 p-0 pt-1 pl-1">
          Since {lastUpdate}
        </div>
      </div>
      }
    </div>
</div>);

ChartCard.propTypes = {
  bg: PropTypes.string,
  className: PropTypes.string
}

export default ChartCard
