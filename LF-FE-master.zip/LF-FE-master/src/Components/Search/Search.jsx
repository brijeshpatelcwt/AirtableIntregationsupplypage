import React, { useRef } from 'react';
import Button from '../Shared/Button/Button';
import { Link } from 'react-router-dom';

const Search = ({placeholder, defaultValue, history, handleChange, state}) => {
  const searchInput = useRef('')
    const search = () => {
      !handleChange ? history.replace(`search-results#?search=${searchInput.current.value}`) : handleChange(searchInput.current.value, state);
      history.replace(`search-results#?search=${searchInput.current.value}`);
    }
    return (
        <div className="header-search">
          <input
            className="search-input"
            ref={searchInput}
            placeholder={placeholder}
            defaultValue={defaultValue}
          />
          <div className="search-button">
            <Button onClick={search} type='submit' text="Search" />
          </div>
          <span className="error"></span>
      </div>
    )
}

export default Search;
