import React from 'react'
import PropTypes from 'prop-types'

import { Navbar, Nav, Button } from 'react-bootstrap';

import logo from '../../Assets/logo.png'
import { Link } from 'react-router-dom';
import Pages from './Pages.json';

const isNotLoginButton = () => {
  return (<>
    <Link to='/login'>
      <Button variant="outline-dark">Login</Button>
    </Link>
    &nbsp; &nbsp; &nbsp;
    <Link to='/create-account'>
    <Button variant="success">Create an account</Button>
    </Link>
    </>)
}

const brandControlle = () => (<Navbar.Brand href="/">
<img
      src={logo}
      height="30"
      className="d-inline-block align-top"
      alt="LEAF LOGO"
    />
</Navbar.Brand>)

const MenuBar = () => {
  const menu = Pages.map((page, key) => (<Link key={key} to={page.url} style={{ "color": "#555", "margin": "0 10px"}}> {page.title}</Link> ));
  return (
    <Nav className="ml-auto">
      { menu }
    </Nav>)
}
const NavBar = ({ bg }) => (
  <Navbar bg={ bg || "white"} expand="sm"variant="light">
  { brandControlle() }
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
    { MenuBar() }
    { isNotLoginButton() }
  </Navbar.Collapse>
</Navbar>);

NavBar.propTypes = {
  bg: PropTypes.string
}

export default NavBar
