import React from 'react';
import PropTypes from 'prop-types';
import { Button as CustomBtn } from 'react-bootstrap';
import './Button.css';

const Button = ({ type, text, onClick, classname }) => (
   <CustomBtn
    className={classname}
    type={type}
    onClick={onClick}
  >
    {text}
  </CustomBtn>
);

Button.propTypes = {
  type: PropTypes.string,
  classname: PropTypes.string,
  onClick: PropTypes.func,
  text: PropTypes.string.isRequired,
};

Button.defaultProps = {
  type: 'submit',
  classname: 'b-button',
};

export default Button;
