import React from 'react';
import './Checkbox.css'
const CheckBox = ({handleSelection,title}) => {
  return (
    <div className="form-check checkbox">
      <label className="form-check-label">
        <input type="checkbox"
          className="form-check-input"
          onChange={handleSelection}
          name={title} />
        {title}
      </label>
    </div>);
}
export default CheckBox;