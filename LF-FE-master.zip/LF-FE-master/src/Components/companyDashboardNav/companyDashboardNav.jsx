import React from 'react';
import './companyDashboardNav.css';
import Octicon, { Home,Gear,Question,ChevronDown } from '@primer/octicons-react';
import supplyItem from '../../Assets/Images/supply-menu-item.svg';
import support from '../../Assets/Images/support.png';
import logo from '../../Assets/logo.png';
import companylogo from '../../Assets/Images/Ellipse 3.png';
import { NavLink, withRouter } from 'react-router-dom';

const companyDashboardNav = (props) => {
    const responsive = () => {
        let x = document.getElementById("topNav");
        if (x.className === "company-nav") {
          x.className += " responsive";
        } else {
          x.className = "company-nav";
        }
      }
    return (
        <>
        <div className="company-header-setup">
            <img src={logo}
                height="30"
                className="d-inline-block align-top"
                alt="LEAF LOGO"
            />
            <div className="info">
            <img height="30" src={companylogo}/>
            <p>Apple inc.</p>
            <span><Octicon icon={ChevronDown}/></span>
            </div>
            </div>
        <div className="company-nav" id="topNav">
        <div className="profile-nav">
            <ul className="nav">
                <NavLink activeClassName="menu-active" exact to={`${props.match.path}company/dashboard`}><li><Octicon className="icon" icon={Home}/>Home</li></NavLink>
                <NavLink activeClassName="menu-active" exact to={`${props.match.path}company/dashboard/goals`}><li><Octicon className="icon" icon={Gear}/><span>Goals</span></li></NavLink>
                <NavLink activeClassName="menu-active" exact to={`${props.match.path}company/dashboard/supply-chain`}><li><img style={{marginRight:"3px"}} src={supplyItem} alt="supply_logo"/><span>Supply chain</span></li></NavLink>
                <NavLink activeClassName="menu-active" exact to={`${props.match.path}company/dashboard/faq`}><li><Octicon className="icon" icon={Question}/><span>FAQs</span></li></NavLink>
                <NavLink activeClassName="menu-active" exact to={`${props.match.path}company/dashboard/support`}><li><img style={{marginRight:"3px"}} src={support} alt="support"/><span>LEAF Support</span></li></NavLink>
                <a href="#" className="icon" onClick={responsive}>
                <i className="fa fa-bars"></i>
                </a>
            </ul>
        </div>  
        </div>
        </>
    )
}

export default withRouter(companyDashboardNav);
