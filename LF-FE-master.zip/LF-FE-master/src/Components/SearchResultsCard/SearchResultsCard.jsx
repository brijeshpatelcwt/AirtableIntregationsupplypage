import React from 'react';
import './SearchResultsCard.css';
import fbLogo from '../../Assets/Images/fb_icon_325x3251.png';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import * as Icons from '@fortawesome/free-brands-svg-icons';

const SearchResultsCard = ({logo, body, title, url}) => {
    return (
        <>
        <div className="col-sm-4">
        <div className="card search-results-card">
        <div className="card-img-top">

    <div className="company-icon p-0 m-0" style={{ "width": "66%", "flex": "none"}}>
            {
              typeof icon === "object" ?
              <span aria-hidden="true">
                  <FontAwesomeIcon style={{ color: '#61a' }} icon={logo} />
              </span>
              :<span aria-hidden="true"><img height="100" width="100" src={logo} style={{
                marginTop: "-40px",
                marginLeft: "-30px"
              }}/></span>
            }
    </div>
        </div>
        <div className="card-body">
          <h5>{title} </h5>
          <p className="card-text">
            { body.split('').splice(0, 100).join('') || 'N/A' } </p>
        </div>
      </div>
      <Link to={`/company/profile#${url || title}`}>
        <button className="view_profile">View Profile</button>
      </Link>
      </div>
      </>
    )
}

export default SearchResultsCard;
