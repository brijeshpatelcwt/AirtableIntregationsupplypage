import React from 'react';
import './GoalsCard.css';


const GoalsCard = ({color,icon,name,no}) => {
    return (
        <div className="col-sm-3">
        <div className="goal-card" style={{backgroundColor:`${color}`}}>
        <span className="card-no">{no}</span>
        <img src={icon} alt="card icon"/>
        <p className="card-name">{name}</p>
        </div>
        </div>
    )
}

export default GoalsCard;
