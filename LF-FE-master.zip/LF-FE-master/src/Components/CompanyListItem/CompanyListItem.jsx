import React from 'react';
import PropTypes from 'prop-types';
import './CompanyListItem.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Link } from 'react-router-dom';

const CompanyListItem = ({ bgColor, icon, companyTitle, companySubtitle, url }) => {
	console.log(icon)
	return <section className="companies-list-item">
		{/* {icon && (
			<div className="company-icon">
				<span aria-hidden="true">
					<FontAwesomeIcon style={{ color: bgColor }} icon={icon} />
				</span>

			</div>
		)} */}
		<div className="company-icon">
		{
			typeof icon === "object"?
			<span aria-hidden="true">
					<FontAwesomeIcon style={{ color: bgColor }} icon={icon} />
			</span>
			:<span aria-hidden="true"><img height="100" width="100" src={icon}/></span>
		}
		</div>



		<div className="company-text">
			<h4> {companyTitle} </h4>
			<p className="text"> {companySubtitle}... </p>
		</div>
		<div className="learn-more-btn">
			<Link to={`/company/profile#${url || companyTitle}`}>
				<button className="learn-btn">Learn More</button>
			</Link>
		</div>
	</section>
};

CompanyListItem.propTypes = {
	icon: PropTypes.string,
	companyTitle: PropTypes.string,
	companySubtitle: PropTypes.string
};

CompanyListItem.defaultProps = {
	type: 'submit',
	classname: 'b-button'
};

export default CompanyListItem;
