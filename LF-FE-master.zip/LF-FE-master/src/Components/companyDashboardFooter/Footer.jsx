import React from 'react';
import './Footer.css';

const Footer = () => {
    return (
        <>
            <div className="dashboard-footer"></div>
            <p className="copyright">© LEAF 2019</p>
            <span className="rights">All rights reserved</span>
        </>
    )
}

export default Footer;
