import React from 'react';
import './InputBox.css';
import { ReactComponent as Icon} from '../../Assets/Images/dropdown.svg'

const InputBox = ({label,textarea, ref, onChange,...otherProps}) => {
    if(textarea){
      return (
        <div className="input_box">
          {label? <label className="label">{label}</label> : null}
          <textarea ref={ref} onChange={onChange} {...otherProps}/> 
        </div>
      );
    }
    return (
        <div className="input_box">
          {label? <label className="label">{label}</label> : null}
          {/* <Icon className="drop"/> */}
          <input  ref={ref} onChange={onChange} {...otherProps}/> 
          
          {/* {icon ? icon : null} */}
        </div>
    )
}

export default InputBox;
