import React from 'react';
import './Card.css';

const Card = ({border,graph,title,percent,index,rating,dropdown,...props}) => {
    return (
        <div className="col-sm-3">
        <div className="company-dashboard-card" style={{border:border? "1px solid #0EB062":''}}>
         <p className="title">{title}</p>
         {graph?<img className={`graph ${props.rect}`} alt="graph" src={graph}/>  :null}
         <span className="percent">{percent}</span> 
         <p className="perf_idx">{index}</p>
         <div style={{marginBottom:"20px",display:"flex"}}>
         <img height="5" width="5" className="rating" src={dropdown} alt="rise"/>
         <p className="rating_num">{rating}</p>
        </div> 
        </div>
        </div>

    )
}

export default Card;
