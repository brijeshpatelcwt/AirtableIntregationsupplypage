import { Auth as AmplifyAuth } from 'aws-amplify';

export async function SignIn({ username, password }) {
 try {
    const user = await AmplifyAuth.signIn(username, password);
     if ((user.challengeName === 'SMS_MFA' ||
         user.challengeName === 'SOFTWARE_TOKEN_MFA') || 
         (user.challengeName === 'NEW_PASSWORD_REQUIRED') || 
         user.challengeName === 'MFA_SETUP') {
         return false;
     } else {
         return await AmplifyAuth.currentSession();
     }
 } catch (err) {
     return err;
 }
}