import tables from './airtableconfig.js';
import Responder from './responser.js'; 


const userTbl = tables('Users');

export const getAllUsers = async ()  => {
 return userTbl.select({
    maxRecords: 10,
    view: "Grid view"
  })
  .eachPage(function page(records, fetchNextPage) {
    records.forEach(function(record) {
         console.log('UserData', record);
    });
   fetchNextPage();
 }, function done(err) {
   if (err) { console.error(err); return; }
 });
}

export const getUser = async (id, maxRecords = 20)  => {    
 const data =  await userTbl.find(id);
  return data;
}