import Airtable from 'airtable'
const table = new Airtable({ apiKey: "key64OdXrH1Y0aZo0" }).base("appHjax74n4pApmdG");

export default table; 

//key64OdXrH1Y0aZo0
//appHjax74n4pApmdG