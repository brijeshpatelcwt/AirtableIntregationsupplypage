export default class Responder {
 constructor(jsxType) {
  this.jsx = jsxType
 }
 getJsx() {
  return this.jsx;
 }

 setJsx(jsx) {
  this.jsx = jsx;
 }

 pushJsx(jsx){
  this.jsx.push(jsx)
 }
}