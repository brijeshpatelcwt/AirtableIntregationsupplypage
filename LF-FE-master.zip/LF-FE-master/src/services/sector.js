import tables from './config';

const sectorTable = tables('Sectors');

export const getAllSectors = async () => {
 return sectorTable.select({
    maxRecords: 3,
    view: "Grid view"
  })
  .eachPage(function page(records, fetchNextPage) {
    records.forEach(function(record) {
     // console.log(record)
    });
   fetchNextPage();
 }, function done(err) {
   if (err) { console.error(err); return; }
 });
}