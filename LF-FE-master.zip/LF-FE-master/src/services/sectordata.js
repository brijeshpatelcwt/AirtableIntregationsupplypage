import tables from './airtableconfig.js';
import Responder from './responser.js'; 


const sectorTbl = tables('Sectors');

export const getAllSectors = async ()  => {
 return sectorTbl.select({
    maxRecords: 10,
    view: "Grid view"
  })
  .eachPage(function page(records, fetchNextPage) {
    records.forEach(function(record) {
         console.log('SectorList', record);
    });
   fetchNextPage();
 }, function done(err) {
   if (err) { console.error(err); return; }
 });
}

export const getSector = async (id, maxRecords = 20)  => {    
 const data =  await sectorTbl.find(id);
  return data;
}