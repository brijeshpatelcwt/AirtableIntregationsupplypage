import tables from './config';
import Responder from './responser.js'; 

const SDGsTable = tables('SDGS');

export const getAllSdgs = async ()  => {
 return SDGsTable.select({
    maxRecords: 3,
    view: "Grid view"
  })
  .eachPage(function page(records, fetchNextPage) {
    records.forEach(function(record) {
      
        // console.log('Retrieved', record);
    });
   fetchNextPage();
 }, function done(err) {
   if (err) { console.error(err); return; }
 });
}

export const getSdgs = async (id, maxRecords = 20)  => {    
 const data =  await SDGsTable.find(id);
  return data;
}
