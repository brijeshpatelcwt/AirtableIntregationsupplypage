import { Auth as AmplifyAuth } from 'aws-amplify';

export async function CreateAccount({ email, name, password, website }) {
 try {
     let customAtrr = {  "custom:role": "user", "custom:isAdmin": "0"  }
     if (email.toLowerCase().search('leaf') !== -1) {
        customAtrr = {  "custom:role": "admin", "custom:isAdmin": "1"  }
     }
    const user = await AmplifyAuth.signUp({
     username: email,
     password,
     attributes: { email, website, name, ...customAtrr },
     validationData: []
     });
     return user;
 } catch (err) {
     return err;
 }
}
