import Airtable from 'airtable'
const table = new Airtable({ apiKey: "key0BngRAqOS79BBG" }).base("appTO9jKWk22Hj2md");

export default table; 

//key0BngRAqOS79BBG
//appTO9jKWk22Hj2md







//keyM5KszzHoBn37oU