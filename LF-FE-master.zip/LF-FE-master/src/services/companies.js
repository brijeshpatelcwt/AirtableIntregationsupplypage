import tables from './config'; 
import Responder from './responser.js'; 

const companiesTable = tables('Companies');
const companyGoalsTable = tables('Company Goals');
const sdgTable = tables('SDGS');

export const getAllCompanies = async ()  => {

  console.log(companiesTable);
 return companiesTable.select({
    maxRecords: 60,
    view: "Company Grouping View"
  })
  .eachPage(function page(records, fetchNextPage) {

   //console.log(records);
    records.forEach(function(record) {
    });
   fetchNextPage();
 }, function done(err) {
   if (err) { console.error(err); return; }
 });
}

export const getCompanyGoal = async (id) => {
  const goals =  await companyGoalsTable.find(id)
  return {...goals.fields, id: goals.fields};
}

export const getAllSDGs = async (maxRecords = 20) => {
  const sdg =  await sdgTable.select({ maxRecords, view: "Grid view" })
    .all()
  return   sdg;
}

export const getCompany = async (id) => {
  try {
    const company =  await companiesTable.find(id);
    const sdgs = await getAllSDGs();

    const companySDG = sdgs?.filter(sdg => {
      if (!company.fields.SDGS) return;
      for(let sdg1 of company.fields.SDGS) {
        if (sdg.id == sdg1) {
          return {id: sdg.id, ...sdg.fields};
        }
      }
    }).map(sdg => ({id: sdg.id, ...sdg.fields}));
    const comp2 = await companiesTable.select({ maxRecords: 90 }).all();
    const similar = comp2?.filter(({ fields }) => {
        for(let sdg of companySDG){

          if((company.fields.Sector && fields.Sector.toLowerCase() === company.fields.Sector.toLowerCase()) || (fields.SDGS.find(sdg1 => sdg.id === sdg1)
            && fields.LeafScore >= Math.floor(Math.random(100) * 80))
            && fields.Company!== company.fields.Company)
              return fields.SDGS;
        }
    }).map( (record) => ({...record.fields, id: record.id})).sort((a, b) => a.LeafScore - b.LeafScore);

    return {...company.fields, id: company.id, SDGS: companySDG, similar };
  } catch (error) {
    throw error
  }
}

export const searchCompany = async (query, maxRecords = 120)  => {
  const data = await  companiesTable.select({
      maxRecords,
      view: "Company Grouping View"
    }).all()

    const d = data.filter(record => record.fields.Company.toLowerCase().search(query.toLowerCase()) !== -1)
    .map( (record) => {
     //console.log('company==', record.fields)
      // const goals = await getCompanyGoal(fields['Company Goals'])
      return {...record.fields, id: record.id}
    });
    return d;
}

export const getSingleCompany = (query) => {
    return companiesTable.select({
        maxRecords: 3,
        view: "Company Grouping View",
        filterByFormula: query
      })
      .eachPage(function page(records, fetchNextPage) {
        records.forEach(function(record) {
        });
       fetchNextPage();
     }, function done(err) {
       if (err) { console.error(err); return; }
     });
}
