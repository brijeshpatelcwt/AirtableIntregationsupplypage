import React from 'react';
import { Route, Switch, BrowserRouter } from 'react-router-dom';

import App from './App';
import CreateAccount from './Pages/CreateAccount/CreateAccount';
import OurCause from './Pages/OurCause/OurCause';
import SupplyChain from './Pages/SupplyChain/SupplyChain';
import SdgLeaderBoard from './Pages/SdgLeaderBoard/SdgLeaderBoard';
import CompanyLeaderBoard from './Pages/companyLeaderBoard/companyLeaderBoard';
import CompanyProfile from './Pages/CompanyProfile/CompanyProfile';
import SearchResults from './Pages/SearchResults/SearchResults';
import CompanySetup from './Pages/CompanySetup/CompanySetup';
import CompanyDashboard from './Pages/Dashboard/Dashboard';
import Login from './Pages/Login/Login';
import AdminDashboard from './Pages/Admin/Dashboard/Dashboard';
import CompanyProfiles from './Pages/Admin/CompanyProfiles/CompanyProfiles';
import LatestUpdate from './Pages/Admin/LatestUpdate/LatestUpdate';

const Routes = () => {
  return (
    <BrowserRouter>
      <Switch>
        <Route exact path="/" component={App} />
        <Route exact path="/create-account" component={CreateAccount} />
        <Route exact path="/our-cause" component={OurCause} />
        <Route exact path="/supply-chain" component={SupplyChain} />
        <Route exact path="/sdg-leaderboard" component={SdgLeaderBoard} />
        <Route exact path="/company-leaderboard" component={CompanyLeaderBoard} />
        <Route exact path="/company/profile" component={CompanyProfile} />
        <Route path="/company/dashboard" component={CompanyDashboard} />
        <Route exact path="/search-results" component={SearchResults} />
        <Route exact path="/company/setup" component={CompanySetup}/>
        <Route exact path="/login" component={Login} />
        <Route exact path="/admin/dashboard" component={AdminDashboard} />
        <Route exact path="/admin/company/profiles" component={CompanyProfiles} />
        <Route exact path="/admin/latest-update" component={LatestUpdate} />
        <Route exact component={App} />
      </Switch>
    </BrowserRouter>
  );
};

export default Routes;
