import { createStore, applyMiddleware, compose } from 'redux';

import defaultReducer from './reducer/index'

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const enhancer = composeEnhancers();
const store = createStore(defaultReducer, enhancer )

export default store