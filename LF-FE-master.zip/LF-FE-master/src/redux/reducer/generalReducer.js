const storeLogin = (payload) => {
    localStorage.setItem(process.env.REACT_APP_STORE_NAME, JSON.stringify(payload));
}
const getLogin = () => {
    const user = localStorage.getItem(process.env.REACT_APP_STORE_NAME);
    return user ? JSON.parse(user) : false;
}
const initialState = {
    companies: [],
    currentUser: { ...getLogin()},
    newSignup: false,
}

const CREATE_ACCOUNT = 'CREATE_ACCOUNT';
const LOGIN_USER = 'LOGIN_USER';
const LOGIN_ADMIN = 'LOGIN_ADMIN';

const LOG_OUT = 'LOG_OUT';

export const createCompanyAccount = (company) => {
    return { type: CREATE_ACCOUNT, response: company }
}
export const loginToAccount = (company) => {
    storeLogin(company);
    return { type: LOGIN_USER, response: company }
}
export const logoutAccount = (company) => {
    return { type: LOG_OUT  }
}

export const loginToAdmin = (response) => {
    storeLogin(response);
    return { type: LOGIN_ADMIN, response }
}

export const createCompany = (company) => {
    return async dispatch => {
        dispatch(createCompanyAccount(company));
    }
}
export const companyLogin = (company) => {
    return async dispatch => {
        dispatch(loginToAccount(company));
    }
}
export const adminLogin = (admin) => {
    return async dispatch => {
        dispatch(loginToAdmin(admin));
    }
}

export const defaultReducer = (state = initialState, action) => {
    switch (action.type) {
        case CREATE_ACCOUNT:
            return {
                ...state,
                currentUser: action.response,
                newSignup: true,
                isAdmin: false
            };

        case LOGIN_USER:
            return {
                ...state,
                currentUser: action.response,
                newSignup: false,
                isAdmin: false
            };

        case LOG_OUT:
            return {
                ...state,
                currentUser: {},
                newSignup: false,
                isAdmin: false,
                adminUser: {}
            };

        case LOGIN_ADMIN:
            return {
                ...state,
                currentUser: null,
                newSignup: false,
                adminUser: action.response,
                isAdmin: true
            };
        default:
            return state;
    }
}