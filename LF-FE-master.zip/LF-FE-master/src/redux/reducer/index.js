import { combineReducers } from 'redux';
import { defaultReducer } from './generalReducer';

export default combineReducers({
    default: defaultReducer
});