export function getPercent(total, active) {
 return  (100 - (total/100 * (total - active))).toFixed(2)
}